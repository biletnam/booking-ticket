﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObjectLayer;
using Entity;
using OBTRS.UserControlList;
namespace OBTRS
{
    public partial class RegisterTicket : System.Web.UI.Page
    {
        List<FormRegister> ReGisList;
       

        protected void Page_Load(object sender, EventArgs e)
        {

            InitForm();
        }
        FindPacket pk;
        private void InitForm()
        {
            #region InitObject
            List<SearchRouteInfomation> Lsr = (List<SearchRouteInfomation>)Session["BookingInfor"];

            pk = (FindPacket)Session["Fpk"];

            ReGisList = new List<FormRegister>();
           

            #endregion
            #region InitTiketTable
            if (Lsr != null)
            {
                P_ID = Convert.ToInt32(Request.QueryString["P_ID"]);
                SearchRouteInfomation sri = Lsr.Find(
                delegate(SearchRouteInfomation sr1)
                {
                    return sr1.P_ID == P_ID;
                });

                lblBusNumber.Text = sri.Bus_Number.ToString();
                lblBusType.Text = sri.Bus_Type;
                lblEndPlace.Text = sri.EndPlace;
                lblEndTime.Text = sri.EndTime;
                lblLeaveDate.Text = sri.StartDate.ToShortDateString();
                lblParking.Text = sri.ParkingPlace;
                lblPrice.Text = pk.GetTotalPrice(sri.Price).ToString();
                lblStartPlace.Text = sri.StartPlace;
                lblStartTime.Text = sri.StartTime;
            }
            #endregion

            
            #region InitRegisterForms

            if (pk.Senior > 0)
            {
                AddForm("Senior citizen", pk.Senior,4);
            }
            if (pk.Adult > 0)
            {
                AddForm("Adult", pk.Adult,3);
            }
            if (pk.Child > 0)
            {
                AddForm("Child", pk.Child,2);
            }
            if (pk.Infan > 0)
            {
                AddForm("Infan", pk.Infan,1);
            }
            #endregion
        }
       
        private void AddForm(String Name,int count,int Sale_ID)
        {
            for (int i = 1; i <= count; i++)
            {
                FormRegister ct = LoadControl("~/UserControlList/FormRegister.ascx") as FormRegister;
                ct.Name = Name+":" + i;
                ct.sales_ID = Sale_ID;
                FormContainer.Controls.Add(ct);
                ReGisList.Add(ct);
            }
        }

        int P_ID;

        protected void BtnBooking_Click(object sender, EventArgs e)
        {
            Bol_Customer bol = new Bol_Customer();
            try
            {
                foreach (FormRegister item in ReGisList)
                {
                    bol.BookingTicket(item.GetCustomerInfor(), item.sales_ID, P_ID);
                }
                FormContainer.Controls.Clear();

            }
            catch (Exception)
            {
                
                throw;
            }
           

        }
    }
}