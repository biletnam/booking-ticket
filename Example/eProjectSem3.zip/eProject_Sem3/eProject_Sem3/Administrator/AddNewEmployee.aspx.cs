﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Reflection;

namespace Administrator
{
    public partial class AddNewEmployee : System.Web.UI.Page
    {
        Bol_Employee be;
        Bol_LevelAuthority bl;
        Bol_Branch bb;
        protected void Page_Load(object sender, EventArgs e)
        {
            be = new Bol_Employee();
            bl = new Bol_LevelAuthority();
            bb = new Bol_Branch();
            if (!IsPostBack)
            {
                ListLV();
                ListBranch();
            }
        }

        private void ListBranch()
        {
            DrBranch.DataSource = bb.getAll();
            DrBranch.DataTextField = "NAME";
            DrBranch.DataValueField = "B_ID";
            DrBranch.DataBind();
        }

        private void ListLV()
        {

            DrLevel.DataSource = bl.getAllLevel();
            DrLevel.DataTextField = "NAME";
            DrLevel.DataValueField = "LV_ID";
            DrLevel.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                Employee em = new Employee();
                Branch b = new Branch();
                em.E_ID = txtID.Text;
                em.FirstName = txtFirstName.Text;
                em.LastName = txtLastName.Text;
                em.USERNAME = txtUser.Text;
                em.PASS = txtPass.Text;
                em.QualiFiCation = txtQuali.Text;
                em.BirthDay = Convert.ToDateTime(txtBirthday.Text);
                em.LV_ID = Convert.ToInt32(DrLevel.SelectedValue);
                em.LocaTion = Convert.ToInt32(DrBranch.SelectedValue);
                em.StaTus = true;
                be.InsertEmployee(em);
                lblEmployee.Text = "Add new complete!";
                lblEmployee.ForeColor = System.Drawing.Color.Blue;
            }
            catch (Exception)
            {
                lblEmployee.Text = "Add new error!";
                lblEmployee.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}