﻿using System;
using System.Collections.Generic;
using BusinessObjectLayer;
using System.Web;
using System.Web.UI;
using Entity;
using System.Web.UI.WebControls;

namespace Administrator
{
    public partial class ChangePass : System.Web.UI.Page
    {
        Bol_Admin bam;
        Admin adm;
        Employee em;
        Bol_Employee bem;
        bool ae;
        protected void Page_Load(object sender, EventArgs e)
        {
            bam = new Bol_Admin();

            bem = new Bol_Employee();

            if (Session["User"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                
                Message.Text = "";
                try
                {
                    adm = (Admin)Session["User"];
                    ae = true;
                    lblName.Text = adm.Username;
                }
                catch (Exception)
                {

                    em = (Employee)Session["User"];
                    lblName.Text = em.USERNAME;
                    ae = false;
                }
            }

        }

        protected void btnChange_Click(object sender, EventArgs e)
        {


            if (txtNewpass.Text == "")
            {
                lblnewpass.Text = "New pass is null !!!";
            }
            else
            {
                if (txtReNewPass.Text == "")
                {
                    lblrenewpass.Text = "Retype pass word is null !!!";
                }
                else
                {
                    if (txtNewpass.Text != txtReNewPass.Text)
                    {
                        lblrenewpass.Text = "Newpass and Retypepass is not same !!!";
                    }
                    else
                    {
                        if (ae)
                        {
                            #region Admin

                            adm.pass = txtNewpass.Text;
                            bam.UpdateAdmin(adm);
                            Session["User"] = adm;
                            #endregion
                        }
                        else
                        {
                            #region Employee


                            em.PASS = txtNewpass.Text;
                            bem.UpdateEmployee(em);
                            Session["User"] = em;
                            #endregion


                        }

                        Message.Text = "Success Change PassWord";
                    }

                }
            }


        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

        }
    }
}