﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Reflection;

namespace eProject_Sem3.Administrator
{
    public partial class Citys1 : System.Web.UI.Page
    {
          City ct;
          Bol_City bol_ct;
        protected void Page_Load(object sender, EventArgs e)
          {
              bol_ct = new Bol_City();
            ct = new City();
            
        }
       
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            ct = new City();
            if (txtSearch.Text == string.Empty)
            {
                lblInfo.Text = "Enter string want search!";
                txtSearch.Focus();
            }
            else
            {
                ct.Ci_ID = Convert.ToInt32(ddlSearch.SelectedValue);
                gvCity.DataSource = bol_ct.SelectCityByID(ct);
                gvCity.DataBind();
                lblInfo.Text = "";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }


   }
}
