﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;

namespace Administrator
{
    public partial class AdminInfo : System.Web.UI.Page
    {
        Bol_Admin ba;
        protected void Page_Load(object sender, EventArgs e)
        {
            ba = new Bol_Admin();
            if (!Page.IsPostBack)
            {
                DropDownList1.DataSource = typeof(Admin).GetProperties();
                DropDownList1.DataTextField = "Name";
                DropDownList1.DataBind();
                getdata();
            }
        }
        public void getdata()
        {
            Bol_Admin bad = new Bol_Admin();
            GridView1.DataSource = bad.SelectAllAdmin();
            GridView1.DataBind();
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            getdata();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            getdata();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Admin adm = new Admin();
            adm.A_id = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[1].Text);
            ba.DeleteAdmin(adm);
            getdata();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;

            getdata();
            ((TextBox)GridView1.Rows[e.NewEditIndex].Cells[1].Controls[0]).Enabled = false;
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Admin adm = new Admin();
            string id = ((TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0]).Text;
            string userName = ((TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0]).Text;
            string pass = ((TextBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0]).Text;
            string fullName = ((TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0]).Text;
            string address = ((TextBox)GridView1.Rows[e.RowIndex].Cells[5].Controls[0]).Text;
            string phoneNumber = ((TextBox)GridView1.Rows[e.RowIndex].Cells[6].Controls[0]).Text;
            adm.A_id = Convert.ToInt32(id);
            adm.Username = userName;
            adm.pass = pass;
            adm.Fullname = fullName;
            adm.address = address;
            adm.phoneNumber = phoneNumber;
            ba.UpdateAdmin(adm);
            GridView1.EditIndex = -1;
            getdata();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
             if (DropDownList1.Text == "A_Id")
            {
                Admin ad = new Admin();
                ad.A_id = Convert.ToInt32(txtSearch.Text);
                GridView1.DataSource = ba.SelectAdminID(ad);
                GridView1.DataBind();


            }
            else if (DropDownList1.Text == "UserName")
            {
                Admin ad = new Admin();
                ad.Username = txtSearch.Text;
                GridView1.DataSource = ba.SelectAdminName(ad);
                GridView1.DataBind();
            }
            else if (DropDownList1.Text == "FullName")
            {
                Admin ad = new Admin();
                ad.Fullname = txtSearch.Text;
                GridView1.DataSource = ba.SelectAdminFullName(ad);
                GridView1.DataBind();
            }
            else if (DropDownList1.Text == "Address")
            {
                Admin ad = new Admin();
                ad.address = txtSearch.Text;
                GridView1.DataSource = ba.SelectAdminAddress(ad);
                GridView1.DataBind();
            }
            else if (DropDownList1.Text == "PhoneNumber")
            {
                Admin ad = new Admin();
                ad.phoneNumber = txtSearch.Text;
                GridView1.DataSource = ba.SelectAdminPhone(ad);
                GridView1.DataBind();
            }
            else if (DropDownList1.Text == "Pass")
            {
                Admin ad = new Admin();
                ad.pass = txtSearch.Text;
                GridView1.DataSource = ba.SelectAdminPass(ad);
                GridView1.DataBind();
            }
        }

        protected void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

       

        
    }
}