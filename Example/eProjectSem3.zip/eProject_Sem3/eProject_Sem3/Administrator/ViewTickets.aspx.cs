﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using BusinessObjectLayer;
using Entity;

namespace Administrator
{
    public partial class ViewTickets : System.Web.UI.Page
    {
        Bol_TicketViews bol_tv;
        Bol_Ticket bol_tk;
        List<TicketViews> listTV;
        protected void Page_Load(object sender, EventArgs e)
        {
            bol_tv = new Bol_TicketViews();
            bol_tk = new Bol_Ticket();
            listTV = bol_tv.GetAllTicketView();
            if (!Page.IsPostBack)
            {
                getlistTicketsInfo();
                lblTotalTicket.Text = "Total ticket :" + gvTicketInfo.Rows.Count.ToString();
            }
            
        }

        private void getlistTicketsInfo()
        {
            gvTicketInfo.DataSource = listTV.FindAll(delegate(TicketViews tk)
            {
                return tk.STATUSISSUE == false;

            });
            gvTicketInfo.DataBind();
        }

        protected void gvTicketInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvTicketInfo.PageIndex = e.NewPageIndex;
            getlistTicketsInfo();
        }

        protected void gvTicketInfo_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvTicketInfo.EditIndex = -1;
            getlistTicketsInfo();
        }

        protected void gvTicketInfo_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvTicketInfo.EditIndex = e.NewEditIndex;
            getlistTicketsInfo();
            ((TextBox)gvTicketInfo.Rows[gvTicketInfo.EditIndex].Cells[2].Controls[0]).Enabled = false;
            ((TextBox)gvTicketInfo.Rows[gvTicketInfo.EditIndex].Cells[3].Controls[0]).Enabled = false;
            ((TextBox)gvTicketInfo.Rows[gvTicketInfo.EditIndex].Cells[4].Controls[0]).Enabled = false;
            ((TextBox)gvTicketInfo.Rows[gvTicketInfo.EditIndex].Cells[5].Controls[0]).Enabled = false;
            ((TextBox)gvTicketInfo.Rows[gvTicketInfo.EditIndex].Cells[6].Controls[0]).Enabled = false;
            ((TextBox)gvTicketInfo.Rows[gvTicketInfo.EditIndex].Cells[7].Controls[0]).Enabled = false;
            ((TextBox)gvTicketInfo.Rows[gvTicketInfo.EditIndex].Cells[8].Controls[0]).Enabled = false;
            
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text == string.Empty)
            {
                lblInfo.Text = "Enter string want search!";
                txtSearch.Focus();
            }
            else
            {
                gvTicketInfo.DataSource = listTV.FindAll(delegate(TicketViews tk)
                {
                    if (ddlSearch.Text == "Bus_Number")
                    {
                        return tk.BUS_NUMBER == txtSearch.Text;

                    }
                    if (ddlSearch.Text == "CustomerName")
                    {
                        return tk.CUSTOMERNAME == txtSearch.Text;
                    }
                    if (ddlSearch.Text == "StartDate")
                    {
                        return tk.STARTDATE == Convert.ToDateTime(txtSearch.Text);
                    }
                    else
                        return false;

                });
                gvTicketInfo.DataBind();
                lblTotalTicket.Text = "Total ticket :" + gvTicketInfo.Rows.Count.ToString();
            }
        }

        protected void cbAvailable_CheckedChanged(object sender, EventArgs e)
        {
            gvTicketInfo.DataSource = listTV.FindAll(delegate(TicketViews tk)
            {
                return tk.STATUSISSUE == cbAvailable.Checked;
            });
            gvTicketInfo.DataBind();
            lblTotalTicket.Text = "Total ticket :" + gvTicketInfo.Rows.Count.ToString();
        }

        protected void gvTicketInfo_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            try
            {
                Ticket tk = new Ticket();
                tk.T_ID = Convert.ToInt32(((TextBox)gvTicketInfo.Rows[e.RowIndex].Cells[2].Controls[0]).Text);
                tk.STATUS = ((CheckBox)gvTicketInfo.Rows[e.RowIndex].Cells[9].Controls[0]).Checked;
                bol_tk.UpdateTicket(tk);

                
                lblInfo.ForeColor = System.Drawing.Color.Blue;
                gvTicketInfo.EditIndex = -1;
                getlistTicketsInfo();
                lblInfo.Text = "Update Success!";
            }
            catch (Exception)
            {
                lblInfo.Text = "Update error!";
                lblInfo.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}