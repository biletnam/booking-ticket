﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Reflection;


namespace Administrator
{
    public partial class Employees : System.Web.UI.Page
    {
        Bol_Employee be;
        Bol_LevelAuthority bl;
        Bol_Branch bb;
        protected void Page_Load(object sender, EventArgs e)
        {
            be = new Bol_Employee();
            bl = new Bol_LevelAuthority();
            bb = new Bol_Branch();
            if (!IsPostBack)
            {
                getlistEmployee();
            }
        }

        private void getlistEmployee()
        {
            GridView1.DataSource = be.getAllEmployee();
            GridView1.DataBind();
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            getlistEmployee();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            getlistEmployee();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string e_id = GridView1.Rows[e.RowIndex].Cells[1].Text;
            Employee em = new Employee();
            em.E_ID = e_id;
            if (be.DeleteEmployee(em) != null)
            {
                be.DeleteEmployee(em);
                getlistEmployee();
                lblEmployee.Text = "Delete complete!";
                lblEmployee.ForeColor = System.Drawing.Color.Blue;
            }
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                Employee em = new Employee();
                em.E_ID = ((TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0]).Text;
                em.FirstName = ((TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0]).Text;
                em.LastName = ((TextBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0]).Text;
                em.USERNAME = ((TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0]).Text;
                em.PASS = ((TextBox)GridView1.Rows[e.RowIndex].Cells[5].Controls[0]).Text;
                em.QualiFiCation = ((TextBox)GridView1.Rows[e.RowIndex].Cells[6].Controls[0]).Text;
                em.BirthDay = Convert.ToDateTime(((TextBox)GridView1.Rows[e.RowIndex].Cells[7].Controls[0]).Text);
                em.LocaTion = Convert.ToInt32(((TextBox)GridView1.Rows[e.RowIndex].Cells[8].Controls[0]).Text);
                em.LV_ID = Convert.ToInt32(((TextBox)GridView1.Rows[e.RowIndex].Cells[9].Controls[0]).Text);
                be.UpdateEmployee(em);
                lblEmployee.Text = "Update complete!";
                lblEmployee.ForeColor = System.Drawing.Color.Blue;
                GridView1.EditIndex = -1;
                getlistEmployee();
            }
            catch (Exception)
            {
                lblEmployee.Text = "Update error!";
                lblEmployee.ForeColor = System.Drawing.Color.Red;
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            getlistEmployee();
            ((TextBox)GridView1.Rows[GridView1.EditIndex].Cells[1].Controls[0]).Enabled = false;
        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddNewEmployee.aspx");
        }
    }
}