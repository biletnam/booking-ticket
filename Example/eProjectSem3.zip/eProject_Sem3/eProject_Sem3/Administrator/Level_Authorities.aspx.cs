﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Reflection;

namespace Administrator
{
    public partial class Level_Authorities : System.Web.UI.Page
    {
        Bol_LevelAuthority bl;
        protected void Page_Load(object sender, EventArgs e)
        {
            bl = new Bol_LevelAuthority();
            if (!Page.IsPostBack)
            {
                getlistEmployee();
            }
        }

        private void getlistEmployee()
        {
            GridView1.DataSource = bl.getAllLevel();
            GridView1.DataBind();
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            getlistEmployee();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            getlistEmployee();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int lv_id = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[1].Text);
            LevelAuthority lv = new LevelAuthority();
            lv.LV_ID = lv_id;
            if (bl.DeleteLevel(lv) != null)
            {
                bl.DeleteLevel(lv);
                getlistEmployee();
                lblLevel.Text = "Delete complete!";
                lblLevel.ForeColor = System.Drawing.Color.Blue;
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            getlistEmployee();
            ((TextBox)GridView1.Rows[GridView1.EditIndex].Cells[1].Controls[0]).Enabled = false;
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                LevelAuthority lv = new LevelAuthority();
                lv.LV_ID = Convert.ToInt32(((TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0]).Text);
                lv.NAME = ((TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0]).Text;
                lv.STATUS = ((CheckBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0]).Checked;
                bl.UpdateLevel(lv);
                lblLevel.Text = "Update complete!";
                lblLevel.ForeColor = System.Drawing.Color.Blue;
                GridView1.EditIndex = -1;
                getlistEmployee();
            }
            catch (Exception)
            {
                lblLevel.Text = "Update error!";
                lblLevel.ForeColor = System.Drawing.Color.Red;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddNewLevel.aspx");
        }

    }
}