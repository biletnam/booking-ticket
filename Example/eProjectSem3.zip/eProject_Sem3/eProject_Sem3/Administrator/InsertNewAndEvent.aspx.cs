﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;

namespace Administrator
{
    public partial class InsertNewAndEvent : System.Web.UI.Page
    {
        Bol_NewAndEvent nae;
        protected void Page_Load(object sender, EventArgs e)
        {
            nae = new Bol_NewAndEvent();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {

            try
            {
                NewAndEvent na = new NewAndEvent();
                na.Title = txtTitle.Text;
                na.Status = CheckBox1.Checked;
                na.Date = Convert.ToDateTime(txtDate.Text);
                na.Author = txtAuthor.Text;
                na.Content = txtContent.Text;
                Label5.Text = "Insert thanh cong!!";
                nae.InsertNewAndEvent(na);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message + "Insert ko thanh cong!!");
            }
        }
    }
}