﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Reflection;

namespace Administrator
{
    public partial class AddNewLevel : System.Web.UI.Page
    {
        Bol_LevelAuthority bl;
        protected void Page_Load(object sender, EventArgs e)
        {
            bl = new Bol_LevelAuthority();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                LevelAuthority la = new LevelAuthority();
                la.NAME = txtName.Text;
                la.STATUS = true;
                bl.InsertLevel(la);
                lblLevel.Text = "Add new complete!";
                lblLevel.ForeColor = System.Drawing.Color.Blue;
            }
            catch (Exception)
            {
                lblLevel.Text = "Add new error!";
                lblLevel.ForeColor = System.Drawing.Color.Red;
            }
        }

    }
}