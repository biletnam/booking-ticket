﻿using System;
using System.Collections.Generic;
using BusinessObjectLayer;
using Entity;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Administrator
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private void login()
        {
            Bol_Employee bEM = new Bol_Employee();
            // implicit predicate delegate.
            Bol_Admin bAD = new Bol_Admin();
            List<Admin> lad = bAD.SelectAllAdmin();
            Admin Ad = lad.Find(
            delegate(Admin ad)
            {
                return (ad.Username.ToLower() == txtUser.Text.ToLower() && ad.pass.ToLower() == txtPass.Text.ToLower());
            });
            if (Ad != null)
            {

                Session["User"] = Ad;

                Response.Redirect("ManagementPage.aspx");
            }
            else
            {
                Employee oem = bEM.getAllEmployee().Find(delegate(Employee em)
             {
                 return (em.USERNAME.ToLower() == txtUser.Text.ToLower() && em.PASS.ToLower() == txtPass.Text.ToLower());
             });
                if (oem != null)
                {
                    Session["User"] = oem;

                    Response.Redirect("ManagementPage.aspx");
                }
                else
                {
                    Message.Text = "Wrong! userName or pass";
                }
            }



        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            login();
        }

    }
}