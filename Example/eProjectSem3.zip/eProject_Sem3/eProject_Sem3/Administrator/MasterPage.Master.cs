﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Web.UI.HtmlControls;
namespace Administrator
{
    public partial class MasterPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                try
                {
                    Admin ad = Session["User"] as Admin;
                    lblInfoAcc.Text = "Well come: " + ad.Fullname + " - Level :Admin";
                }
                catch (Exception)
                {
                    Bol_LevelAuthority bem = new Bol_LevelAuthority();
                    LevelAuthority lv = new LevelAuthority();
                    Employee em = Session["User"] as Employee;
                    lv.LV_ID = em.LV_ID;
                    lv = bem.getLevelbyID(lv)[0];
                    lblInfoAcc.Text = "Well come: " + em.USERNAME + " - Level :" + lv.NAME;
                   
                    if (lv.NAME == "TICKET MANAGER")
                    {

                        Menu(mn, false);
                        Menu(hm, true);
                    }
                }

            }
        }
        private void Menu(Control cl, bool mode)
        {

            foreach (Control item in cl.Controls)
            {
                if (item is LinkButton)
                {
                    LinkButton lb = item as LinkButton;
                    if (mode){

                        lb.Enabled = mode;
                    }
                    else
                    {
                        lb.Enabled = mode;
                    }
                }
            }
        
        }
        protected void lbtnSignout_Click(object sender, EventArgs e)
        {
            Session["User"] = null;
            Response.Redirect("Login.aspx");
        }
    }
}