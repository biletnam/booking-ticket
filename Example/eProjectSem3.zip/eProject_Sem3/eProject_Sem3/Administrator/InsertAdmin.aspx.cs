﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;

namespace Administrator
{
    public partial class InsertAdmin : System.Web.UI.Page
    {
        Bol_Admin bad;
        protected void Page_Load(object sender, EventArgs e)
        {
            bad = new Bol_Admin();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Admin ad = new Admin();
                ad.Username = txtUser.Text;
                ad.phoneNumber = txtPhone.Text;
                ad.pass = txtPass.Text;
                ad.Fullname = txtFullName.Text;
                ad.address = txtAddress.Text;
                Label1.Text = "Insert thanh cong!!";
                bad.InsertAdmin(ad);

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message + "Insert ko thanh cong!!");
            }
        }
    }
}