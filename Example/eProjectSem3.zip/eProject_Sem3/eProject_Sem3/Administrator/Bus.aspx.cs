﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObjectLayer;
using Entity;
namespace Administrator
{
    public partial class Bus : System.Web.UI.Page
    {
        Bol_BusType bBT;
        Bol_Bus bot;
        protected void Page_Load(object sender, EventArgs e)
        {
            bBT = new Bol_BusType();
          bot=  new Bol_Bus();
          if (!IsPostBack)
              adSo();
        }
        private void adSo()
        {
            gvCity.DataSource = bot.SelectAllBus();
            gvCity.DataBind();
        }
        public String GetBustypeByID(int ID)
        { 
           
            BusType bt= bBT.SelectAllBusType().Find(delegate(BusType blt){
                return blt.BT_ID == ID;
            });
            return bt.Name;
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected  void gvCity_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
           ObjectDataSource dtb= gvCity.Rows[e.RowIndex].FindControl("BTDataSource") as ObjectDataSource;
           
            Entity.Bus bl = new Entity.Bus();
            bl.Bus_Number = ((TextBox)gvCity.Rows[e.RowIndex].Cells[1].Controls[0]).Text;
            bl.Seat =Convert.ToInt32( ((TextBox)gvCity.Rows[e.RowIndex].Cells[2].Controls[0]).Text);
            bl.BT_ID = Convert.ToInt32((gvCity.Rows[e.RowIndex].FindControl("DropDownList1") as DropDownList).SelectedValue);
            bl.Status = ((CheckBox)gvCity.Rows[e.RowIndex].Cells[4].Controls[0]).Checked;
            bot.UpdateBusByBusNumber(bl);
            gvCity.EditIndex = -1;
            adSo();

        }

        protected void gvCity_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvCity.EditIndex = e.NewEditIndex;
            adSo();
        }
    }
}