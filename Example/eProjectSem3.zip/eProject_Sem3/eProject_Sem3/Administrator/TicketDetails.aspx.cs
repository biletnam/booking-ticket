﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObjectLayer;
using Entity;

namespace Administrator
{
    public partial class TicketDetails : System.Web.UI.Page
    {
        Bol_TicketViews bol_tv;
       
        protected void Page_Load(object sender, EventArgs e)
        {
            string cus_id = Request.QueryString["Cus_ID"];
            bol_tv = new Bol_TicketViews();
            TicketViews tkv = bol_tv.GetAllTicketView().Find(delegate(TicketViews tv)
            {
                return tv.CUS_ID == Convert.ToInt32(cus_id);
            });

            lblBustype.Text = tkv.BUSTYPE;
            lblRoute.Text = tkv.STARTPLACE + " - " + tkv.ENDPLACE;
            lblBusNumber.Text = tkv.BUS_NUMBER.ToString();
            lblSeatNo.Text = tkv.SEATNUMBER.ToString();
            lblStartdate.Text = tkv.STARTDATE.ToString();
            lblStartTime.Text = tkv.STARTTIME;
            lblEndTime.Text = tkv.ENDTIME;
            lblCustomerName.Text = tkv.CUSTOMERNAME;
            lblPrice.Text = tkv.PRICE.ToString()+"$";
        }
    }
}