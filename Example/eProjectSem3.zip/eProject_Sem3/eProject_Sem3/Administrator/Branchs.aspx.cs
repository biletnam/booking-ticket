﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Reflection;

namespace Administrator
{
    public partial class Branchs : System.Web.UI.Page
    {
        Bol_Branch bb;
        Branch b;
        List<Branch> lb;
        protected void Page_Load(object sender, EventArgs e)
        {
            bb = new Bol_Branch();
            b = new Branch();
            lb = new List<Branch>();
            if (!Page.IsPostBack)
            {
                DropDownList1.DataSource = GetColum();
                DropDownList1.DataBind();
                lb = bb.getAll();
                getlistBranch();
            }
        }

        private List<String> GetColum()
        {
            List<String> ls = new List<string>();
            Type p = typeof(Branch);
            PropertyInfo[] pL = p.GetProperties();
            foreach (PropertyInfo item in pL)
            {
                ls.Add(item.Name);
            }
            return ls;
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            b = new Branch();
            bb = new Bol_Branch();
            if (TextBox1.Text == "")
            {
                Response.Write("Vui long nhap tu khoa muon tim !!!");
                TextBox1.Focus();
            }
            else
            {
                if (DropDownList1.SelectedValue.ToString() == "B_id")
                {
                    if (bb.CheckBranchExistByID(Convert.ToInt32(TextBox1.Text)) == 0)
                    {
                        b.B_ID = Convert.ToInt32(TextBox1.Text);
                        GridView1.DataSource = bb.getAllbyID(b);
                        GridView1.DataBind();
                        TextBox1.Text = "";
                    }
                    else
                    {
                        Response.Write("ID nay khong ton tai !!!");
                        TextBox1.Text = "";
                        TextBox1.Focus();
                    }
                }
                else if (DropDownList1.SelectedValue.ToString() == "Name")
                {
                    if (bb.CheckBranchExistByName(TextBox1.Text) == 0)
                    {
                        b.NAME = TextBox1.Text;
                        GridView1.DataSource = bb.getAllbyName(b);
                        GridView1.DataBind();
                        TextBox1.Text = "";
                    }
                    else
                    {
                        Response.Write("Name nay khong ton tai !!!");
                        TextBox1.Text = "";
                        TextBox1.Focus();
                    }
                }
                else if (DropDownList1.SelectedValue.ToString() == "PhoneNumber")
                {
                    if (bb.CheckBranchExistByName(TextBox1.Text) == 0)
                    {
                        b.PHONENUMBER = TextBox1.Text;
                        GridView1.DataSource = bb.getAllbyName(b);
                        GridView1.DataBind();
                        TextBox1.Text = "";
                    }
                    else
                    {
                        Response.Write("Phone Number nay khong ton tai !!!");
                        TextBox1.Text = "";
                        TextBox1.Focus();
                    }
                }
                else if (DropDownList1.SelectedValue.ToString() == "Address")
                {
                    if (bb.CheckBranchExistByName(TextBox1.Text) == 0)
                    {
                        b.ADDRESS = TextBox1.Text;
                        GridView1.DataSource = bb.getAllbyName(b);
                        GridView1.DataBind();
                        TextBox1.Text = "";
                    }
                    else
                    {
                        Response.Write("Address nay khong ton tai !!!");
                        TextBox1.Text = "";
                        TextBox1.Focus();
                    }
                }
            }
        }

        private void getlistBranch()
        {
            GridView1.DataSource = bb.getAll();
            GridView1.DataBind();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            getlistBranch();
            ((TextBox)GridView1.Rows[GridView1.EditIndex].Cells[1].Controls[0]).Enabled = false;
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            getlistBranch();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                Branch b = new Branch();
                b.B_ID = Convert.ToInt32(((TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0]).Text);
                b.NAME = ((TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0]).Text;
                b.PHONENUMBER = ((TextBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0]).Text;
                b.ADDRESS = ((TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0]).Text;
                b.STATUS = ((CheckBox)GridView1.Rows[e.RowIndex].Cells[5].Controls[0]).Checked;
                bb.UpdateBranch(b);
                lblBranch.Text = "Update complete!";
                lblBranch.ForeColor = System.Drawing.Color.Blue;
                GridView1.EditIndex = -1;
                getlistBranch();
            }
            catch (Exception)
            {
                lblBranch.Text = "Update error!";
                lblBranch.ForeColor = System.Drawing.Color.Red;
            }
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            getlistBranch();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int b_id = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[1].Text);
            Branch b = new Branch();
            b.B_ID = b_id;
            if (bb.DeleteBranch(b) != null)
            {
                bb.DeleteBranch(b);
                getlistBranch();
                lblBranch.Text = "Delete complete!";
                lblBranch.ForeColor = System.Drawing.Color.Blue;
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddNewBranch.aspx");
        }

    }
}
