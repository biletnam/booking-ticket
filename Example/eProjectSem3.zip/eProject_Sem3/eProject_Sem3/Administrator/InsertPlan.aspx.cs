﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Data;

namespace Administrator
{
    public partial class InsertPlan : System.Web.UI.Page
    {
        Bol_Plan bp;
        protected void Page_Load(object sender, EventArgs e)
        {
            bp = new Bol_Plan();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                Plan p = new Plan();
                p.BusNumber = DropDownList4.Text;
                p.PP_ID = Convert.ToInt32(DropDownList2.Text);
                p.Rou_ID = Convert.ToInt32(DropDownList1.Text);
                p.TS_ID = Convert.ToInt32(DropDownList3.Text);
                p.StartDate = Convert.ToDateTime(txtStartDate.Text);
                Label1.Text = "Insert thanh cong!!!";
                bp.InsertPlan(p);
            }
            catch(Exception ex)

            {
                Response.Write(ex.Message + "Insert khong thanh cong!!");
            }
        }

      
    }

}