﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Reflection;//Lay thong tin cua class

namespace Administrator
{
    public partial class CustomerInfo : System.Web.UI.Page
    {
        Bol_Customer bol_cus;
        protected void Page_Load(object sender, EventArgs e)
        {
            bol_cus = new Bol_Customer();
            if (!Page.IsPostBack)
            {
                ddlSearch.DataSource = typeof(Customers).GetProperties();
                ddlSearch.DataTextField = "Name";
                ddlSearch.DataBind();
                getlistCustomer();
            }

        }

        private void getlistCustomer()
        {
            gvCustomer.DataSource = bol_cus.SelectAllCustomer();
            gvCustomer.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text == string.Empty)
            {
                lblInfo.Text = "Enter string want search!";
                txtSearch.Focus();
            }
            else
            {
                gvCustomer.DataSource = bol_cus.SearchCustomer(ddlSearch.SelectedItem.ToString(), txtSearch.Text);
                gvCustomer.DataBind();
                lblInfo.Text = "";
            }
        }

        protected void gvCustomer_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvCustomer.PageIndex = e.NewPageIndex;
            getlistCustomer();
        }

        protected void gvCustomer_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvCustomer.EditIndex = e.NewEditIndex;
            getlistCustomer();
            ((TextBox)gvCustomer.Rows[gvCustomer.EditIndex].Cells[2].Controls[0]).Enabled = false;
        }

        protected void gvCustomer_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int cus_id = Convert.ToInt32(gvCustomer.Rows[e.RowIndex].Cells[2].Text);
            Customers cus = new Customers();
            cus.CUS_ID = cus_id;
            if (bol_cus.DeleteCustomer(cus) != null)
            {
                bol_cus.DeleteCustomer(cus);
                getlistCustomer();
                lblInfo.Text = "Delete complete!";
                lblInfo.ForeColor = System.Drawing.Color.Blue;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            getlistCustomer();
        }

        protected void gvCustomer_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvCustomer.EditIndex = -1;
            getlistCustomer();
        }

        protected void gvCustomer_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                Customers cus = new Customers();
                cus.CUS_ID = Convert.ToInt32(((TextBox)gvCustomer.Rows[e.RowIndex].Cells[2].Controls[0]).Text);
                cus.FIRSTNAME = ((TextBox)gvCustomer.Rows[e.RowIndex].Cells[3].Controls[0]).Text;
                cus.LASTNAME = ((TextBox)gvCustomer.Rows[e.RowIndex].Cells[4].Controls[0]).Text;
                cus.ADDRESS = ((TextBox)gvCustomer.Rows[e.RowIndex].Cells[5].Controls[0]).Text;
                cus.EMAIL = ((TextBox)gvCustomer.Rows[e.RowIndex].Cells[6].Controls[0]).Text;
                cus.REGISTERDATE = Convert.ToDateTime(((TextBox)gvCustomer.Rows[e.RowIndex].Cells[7].Controls[0]).Text);
                cus.PHONENUMBER = ((TextBox)gvCustomer.Rows[e.RowIndex].Cells[8].Controls[0]).Text;
                cus.STATUS = ((CheckBox)gvCustomer.Rows[e.RowIndex].Cells[9].Controls[0]).Checked;
                bol_cus.UpdateCustomer(cus);
                lblInfo.Text = ((CheckBox)gvCustomer.Rows[e.RowIndex].Cells[9].Controls[0]).Checked.ToString();
                lblInfo.ForeColor = System.Drawing.Color.Blue;
                gvCustomer.EditIndex = -1;
                getlistCustomer();
            }
            catch (Exception)
            {
                lblInfo.Text = "Update error!";
                lblInfo.ForeColor = System.Drawing.Color.Red;
            }
            

        }


    }
}