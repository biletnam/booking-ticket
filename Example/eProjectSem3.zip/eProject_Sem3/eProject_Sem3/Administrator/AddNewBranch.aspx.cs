﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BusinessObjectLayer;
using System.Reflection;

namespace Administrator
{
    public partial class AddNewBranch : System.Web.UI.Page
    {
        Bol_Branch bb;
        Branch b;
        List<Branch> lb;
        protected void Page_Load(object sender, EventArgs e)
        {
            bb = new Bol_Branch();
            b = new Branch();
            lb = new List<Branch>();
        }

        private List<String> GetColum()
        {
            List<String> ls = new List<string>();
            Type p = typeof(Branch);
            PropertyInfo[] pL = p.GetProperties();
            foreach (PropertyInfo item in pL)
            {
                ls.Add(item.Name);
            }
            return ls;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                b = new Branch();
                b.NAME = txtName.Text;
                b.PHONENUMBER = txtPhoneNumber.Text;
                b.ADDRESS = txtAddress.Text;
                b.STATUS = CheckBox1.Checked;
                bb.InsertBranch(b);
                lblBranch.Text = "Add new complete!";
                lblBranch.ForeColor = System.Drawing.Color.Blue;
            }
            catch (Exception)
            {
                lblBranch.Text = "Add new error!";
                lblBranch.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}