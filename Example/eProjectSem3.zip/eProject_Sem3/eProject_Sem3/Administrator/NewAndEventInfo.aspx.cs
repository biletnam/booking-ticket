﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObjectLayer;
using Entity;


namespace Administrator
{
    public partial class NewAndEventInfo : System.Web.UI.Page
    {
        Bol_NewAndEvent bna;
        protected void Page_Load(object sender, EventArgs e)
        {
            bna = new Bol_NewAndEvent();
            //if (!IsPostBack)
            //{
            //    DropDownList1.DataSource = typeof(NewAndEvent).GetProperties();
            //    DropDownList1.DataTextField = "Name";
            //    DropDownList1.DataBind();

            //}
            if (!Page.IsPostBack)
            {
                DropDownList1.DataSource = typeof(NewAndEvent).GetProperties();
                DropDownList1.DataTextField = "Name";
                DropDownList1.DataBind();
                getdata();

            }

        }
        public void getdata()
        {
            Bol_NewAndEvent nae = new Bol_NewAndEvent();
            GridView1.DataSource = nae.SelectNewAndEvent();
            GridView1.DataBind();
        }


        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            getdata();

        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            getdata();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            NewAndEvent nae = new NewAndEvent();
            nae.NE_Id = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[1].Text);
            bna.DeleteNewAndEventID(nae);
            getdata();
            
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
             GridView1.EditIndex = e.NewEditIndex;
            getdata();
            ((TextBox)GridView1.Rows[e.NewEditIndex].Cells[1].Controls[0]).Enabled = false;
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            NewAndEvent nae = new NewAndEvent();
            string id = ((TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0]).Text;
            string title = ((TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0]).Text;
            string content = ((TextBox)GridView1.Rows[e.RowIndex].Cells[3].Controls[0]).Text;
            string author = ((TextBox)GridView1.Rows[e.RowIndex].Cells[4].Controls[0]).Text;
            string date = ((TextBox)GridView1.Rows[e.RowIndex].Cells[5].Controls[0]).Text;
            string status = ((CheckBox)GridView1.Rows[e.RowIndex].Cells[6].Controls[0]).Checked.ToString();

            nae.Title = title;
            nae.NE_Id = Convert.ToInt32(id);
            nae.Content = content;
            nae.Author = author;
            nae.Date = Convert.ToDateTime(date);
            nae.Status = Convert.ToBoolean(status);

            bna.UpdateNewAndEvent(nae);
            GridView1.EditIndex = -1;
            getdata();

        }

        //protected void btnSearch_Click(object sender, EventArgs e)
        //{
           
        
           

        //}

        protected void btnSearch_Click1(object sender, EventArgs e)
        {

            if (DropDownList1.Text == "NE_Id")
            {
                NewAndEvent nea = new NewAndEvent();
                nea.NE_Id = Convert.ToInt32(txtSearch.Text);
                GridView1.DataSource = bna.SelectbyID(nea);
                GridView1.DataBind();
                // getdata();
            }
            else if (DropDownList1.Text == "Title")
            {
                NewAndEvent nea = new NewAndEvent();
                nea.Title = txtSearch.Text;
                GridView1.DataSource = bna.SelectTitleNewAndEvent(nea);
                GridView1.DataBind();
            }
            else if (DropDownList1.Text == "Content")
            {
                NewAndEvent nea = new NewAndEvent();
                nea.Content = txtSearch.Text;
                GridView1.DataSource = bna.SelectNewAndEventContent(nea);
                GridView1.DataBind();
            }
            else if (DropDownList1.Text == "Author")
            {
                NewAndEvent nea = new NewAndEvent();
                nea.Author = txtSearch.Text;
                GridView1.DataSource = bna.SelectNewAndEventAuthor(nea);
                GridView1.DataBind();
            }
            else if (DropDownList1.Text == "Date")
            {
                NewAndEvent nea = new NewAndEvent();
                nea.Date = Convert.ToDateTime(txtSearch.Text);
                GridView1.DataSource = bna.SelectNewAndEventDate(nea);
                GridView1.DataBind();
            }
            else if (DropDownList1.Text == "Status")
            {
                NewAndEvent nea = new NewAndEvent();
                nea.Status = Convert.ToBoolean(txtSearch.Text);
                GridView1.DataSource = bna.SelectNewAndEventStatus(nea);
                GridView1.DataBind();

            }
        }

        protected void btnAddnew_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Administrator/InsertNewAndEvent.aspx");
        }
    }
}