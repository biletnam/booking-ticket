﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class TimeSlot
    {
        public TimeSlot()
        {

        }
        private int TS_Id;

        public int  TS_ID
        {
            get { return TS_Id; }
            set { TS_Id = value; }
        }
        private String  Starttime;

        public String  StartTime
        {
            get { return Starttime; }
            set { Starttime = value; }
        }
        private String Endtime;

        public String EndTime
        {
            get { return Endtime; }
            set { Endtime = value; }
        }
        
    }
}