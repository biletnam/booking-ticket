﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class Plan
    {
    
        public Plan()
        {

        }
        private int P_Id;

        public int P_ID
        {
            get { return P_Id; }
            set { P_Id = value; }
        }

        private int Rou_Id;
        public int Rou_ID
        {
            get { return Rou_Id; }
            set { Rou_Id = value; }
        }
      

        private int PP_Id;

        public int PP_ID
        {
            get { return PP_Id; }
            set { PP_Id = value; }
        }

        private String Bus_Number;

        public String BusNumber
        {
            get { return Bus_Number; }
            set { Bus_Number = value; }
        }

        private int TS_Id;

        public int TS_ID
        {
            get { return TS_Id; }
            set { TS_Id = value; }
        }
        private DateTime Start_Date;

        public DateTime StartDate
        {
            get { return Start_Date; }
            set { Start_Date = value; }
        }
        
    }
}