﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class Customers
    {
        private int Cus_Id;

        public int CUS_ID
        {
            get { return Cus_Id; }
            set { Cus_Id = value; }
        }
        private string FirstName;

        public string FIRSTNAME
        {
            get { return FirstName; }
            set { FirstName = value; }
        }
        private string LastName;

        public string LASTNAME
        {
            get { return LastName; }
            set { LastName = value; }
        }
        private string Address;

        public string ADDRESS
        {
            get { return Address; }
            set { Address = value; }
        }

        private string Email;

        public string EMAIL
        {
            get { return Email; }
            set { Email = value; }
        }
        
        private DateTime RegisterDate;

        public DateTime REGISTERDATE
        {
            get { return RegisterDate; }
            set { RegisterDate = value; }
        }
        private string PhoneNumber;

        public string PHONENUMBER
        {
            get { return PhoneNumber; }
            set { PhoneNumber = value; }
        }
        private bool Status;

        public bool STATUS
        {
            get { return Status; }
            set { Status = value; }
        }
    }
}