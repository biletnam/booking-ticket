﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class TicketReturn
    {
        public TicketReturn()
        {

        }

        private int TR_Id;

        public int TR_ID
        {
            get { return TR_Id; }
            set { TR_Id = value; }
        }

        private DateTime ReturnDate;

        public DateTime RETURNDATE
        {
            get { return ReturnDate; }
            set { ReturnDate = value; }
        }

        private int DI_Id;

        public int DI_ID
        {
            get { return DI_Id; }
            set { DI_Id = value; }
        }

        private double ReturnPrice;

        public double RETURNPRICE
        {
            get { return ReturnPrice; }
            set { ReturnPrice = value; }
        }
        
    }
}