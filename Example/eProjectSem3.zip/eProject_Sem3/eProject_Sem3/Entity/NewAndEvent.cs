﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class NewAndEvent
    {
        private int NE_id;

        public int NE_Id
        {
            get { return NE_id; }
            set { NE_id = value; }
        }

        private string title;

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        private string content;

        public string Content
        {
            get { return content; }
            set { content = value; }
        }

        private string author;

        public string Author
        {
            get { return author; }
            set { author = value; }
        }

        private DateTime date;

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        private Boolean status;

        public Boolean Status
        {
            get { return status; }
            set { status = value; }
        }
    }
}

