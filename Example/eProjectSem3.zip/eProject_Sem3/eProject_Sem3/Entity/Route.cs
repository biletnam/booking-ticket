﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class Route
    {
        public Route()
        {

        }
       
        private int Rou_Id;

        public int Rou_ID
        {
            get { return Rou_Id; }
            set { Rou_Id = value; }
        }
        private String name;

        public String Name
        {
            get { return name; }
            set { name = value; }
        }
        private int Startplace;

        public int StartPlace
        {
            get { return Startplace; }
            set { Startplace = value; }
        }
        private int Endplace;

        public int EndPlace
        {
            get { return Endplace; }
            set { Endplace = value; }
        }
        private int distance;

        public int Distance
        {
            get { return distance; }
            set { distance = value; }
        }
        private DateTime Startdate;

        public DateTime StartDate
        {
            get { return Startdate; }
            set { Startdate = value; }
        }
        private double price;

        public double Price
        {
            get { return price; }
            set { price = value; }
        }
        private String description;

        public String Description
        {
            get { return description; }
            set { description = value; }
        }
        private bool status;

        public bool Status
        {
            get { return status; }
            set { status = value; }
        }
        
        
        
    }
}