﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class Employee
    {
        private string E_Id;

        public string E_ID
        {
            get { return E_Id; }
            set { E_Id = value; }
        }

        private string Firstname;

        public string FirstName
        {
            get { return Firstname; }
            set { Firstname = value; }
        }

        private string Lastname;

        public string LastName
        {
            get { return Lastname; }
            set { Lastname = value; }
        }

        private string UserName;

        public string USERNAME
        {
            get { return UserName; }
            set { UserName = value; }
        }

        private string Pass;

        public string PASS
        {
            get { return Pass; }
            set { Pass = value; }
        }

        private string Qualification;

        public string QualiFiCation
        {
            get { return Qualification; }
            set { Qualification = value; }
        }

        private DateTime Birthday;

        public DateTime BirthDay
        {
            get { return Birthday; }
            set { Birthday = value; }
        }

        private int Location;

        public int LocaTion
        {
            get { return Location; }
            set { Location = value; }
        }

        private int LV_Id;

        public int LV_ID
        {
            get { return LV_Id; }
            set { LV_Id = value; }
        }

        private Boolean Status;

        public Boolean StaTus
        {
            get { return Status; }
            set { Status = value; }
        }
    }
}