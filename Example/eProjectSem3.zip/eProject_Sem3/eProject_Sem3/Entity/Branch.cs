﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class Branch
    {
        private int B_id;

        public int B_ID
        {
            get { return B_id; }
            set { B_id = value; }
        }

        private String Name;

        public String NAME
        {
            get { return Name; }
            set { Name = value; }
        }

        private String PhoneNumber;

        public String PHONENUMBER
        {
            get { return PhoneNumber; }
            set { PhoneNumber = value; }
        }

        private String Address;

        public String ADDRESS
        {
            get { return Address; }
            set { Address = value; }
        }

        private Boolean Status;

        public Boolean STATUS
        {
            get { return Status; }
            set { Status = value; }
        }
    }
}
