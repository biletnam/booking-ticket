﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class Admin
    {
        private int A_Id;

        public int A_id
        {
            get { return A_Id; }
            set { A_Id = value; }
        }
        private string UserName;

        public string Username
        {
            get { return UserName; }
            set { UserName = value; }
        }

        private string Pass;

        public string pass
        {
            get { return Pass; }
            set { Pass = value; }
        }

        private string FullName;

        public string Fullname
        {
            get { return FullName; }
            set { FullName = value; }
        }

        private string Address;

        public string address
        {
            get { return Address; }
            set { Address = value; }
        }

        private string PhoneNumber;

        public string phoneNumber
        {
            get { return PhoneNumber; }
            set { PhoneNumber = value; }
        }
        
        
        
        


    }
}