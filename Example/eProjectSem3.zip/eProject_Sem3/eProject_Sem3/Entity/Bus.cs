﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class Bus
    {
        private string Bus_number;

        public string Bus_Number
        {
            get { return Bus_number; }
            set { Bus_number = value; }
        }
        private int seat;

        public int Seat
        {
            get { return seat; }
            set { seat = value; }
        }
        private int BT_Id;

        public int BT_ID
        {
            get { return BT_Id; }
            set { BT_Id = value; }
        }

        private bool status;

        public bool Status
        {
            get { return status; }
            set { status = value; }
        }
        
        
    }
}