﻿using System;
using System.Collections.Generic;
using System.Web;
using BusinessObjectLayer;
namespace Entity
{
    public class FindPacket
    {
        private int adult;

        public int Adult
        {
            get { return adult; }
            set { adult = value; }
        }
        private int senior;

        public int Senior
        {
            get { return senior; }
            set { senior = value; }
        }
        private int child;

        public int Child
        {
            get { return child; }
            set { child = value; }
        }
        private int infan;

        public int Infan
        {
            get { return infan; }
            set { infan = value; }
        }
        
        private int Bus_Type;

        public int BusType
        {
            get { return Bus_Type; }
            set { Bus_Type = value; }
        }

        private int Start_Place;
        public int StartPlace
        {
            get { return Start_Place; }
            set { Start_Place = value; }
        }
      
        private int End_Place;
        public int EndPlace
        {
            get { return End_Place; }
            set { End_Place = value; }
        }
        private DateTime Start_Date;

        public DateTime StartDate
        {
            get { return Start_Date; }
            set { Start_Date = value; }
        }
              
        public double GetTotalPrice( double Price)
        {
         
            Bol_Sales bSA = new Bol_Sales();
            List<Sales> lSa = bSA.SelectSalesAll();

        double total= Calculate(GetRate(4, lSa), Price, senior) + Calculate(GetRate(3, lSa), Price, adult) +
              Calculate(GetRate(2, lSa), Price, child) + Calculate(GetRate(1, lSa), Price, infan);

        bSA = null;
        lSa = null;
        return total;
        }

        private double Calculate(int Rate, double Price, int TraverlerNo)
        {
            return (Price - Price * Rate / 100) * TraverlerNo;
        }

        private int GetRate(int ID, List<Sales> lSa)
        {
            Sales sa = lSa.Find(delegate(Sales Tsa)
            {
                return Tsa.Sa_ID == ID;
            });
            return sa.Rate;
        }
    }
}