﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class SearchRouteInfomation
    {

        public SearchRouteInfomation()
        {

        }         
        private String Bus_number;

        public String Bus_Number
        {
            get { return Bus_number; }
            set { Bus_number = value; }
        }
        private int Empty_seats;

        public int Empty_Seats
        {
            get { return Empty_seats; }
            set { Empty_seats = value; }
        }
        private String Starttime;

        public String StartTime
        {
            get { return Starttime; }
            set { Starttime = value; }
        }
        private String Endtime;

        public String EndTime
        {
            get { return Endtime; }
            set { Endtime = value; }
        }
        private String Bus_type;

        public String Bus_Type
        {
            get { return Bus_type; }
            set { Bus_type = value; }
        }
        private DateTime Start_Date;

        public DateTime StartDate
        {
            get { return Start_Date; }
            set { Start_Date = value; }
        }

        private String Start_Place;

        public String StartPlace
        {
            get { return Start_Place; }
            set { Start_Place = value; }
        }
        private String End_Place;

        public String EndPlace
        {
            get { return End_Place; }
            set { End_Place = value; }
        }
        private String Parking_Place;

        public String ParkingPlace
        {
            get { return Parking_Place; }
            set { Parking_Place = value; }
        }
        private double price;

        public double Price
        {
            get { return price; }
            set { price = value; }
        }
         private double P_Id;

         public double P_ID
        {
            get { return P_Id; }
            set { P_Id = value; }
        }
    }
}