﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class Ticket

    {
        public Ticket()
        {

        }
        private int T_Id;

        public int T_ID
        {
            get { return T_Id; }
            set { T_Id = value; }
        }

        private int Cus_Id;

        public int CUS_ID
        {
            get { return Cus_Id; }
            set { Cus_Id = value; }
        }
        private int Sa_Id;

        public int SA_ID
        {
            get { return Sa_Id; }
            set { Sa_Id = value; }
        }

        private int P_Id;

        public int P_ID
        {
            get { return P_Id; }
            set { P_Id = value; }
        }

        private int SeatNumber;

        public int SEATNUMBER
        {
            get { return SeatNumber; }
            set { SeatNumber = value; }
        }

        private double Price;

        public double PRICE
        {
            get { return Price; }
            set { Price = value; }
        }

        private bool Return;

        public bool RETURN
        {
            get { return Return; }
            set { Return = value; }
        }
        private bool Status;

        public bool STATUS
        {
            get { return Status; }
            set { Status = value; }
        }
        
    }
}