﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class LevelAuthority
    {
        private int LV_Id;

        public int LV_ID
        {
            get { return LV_Id; }
            set { LV_Id = value; }
        }


        private String Name;

        public String NAME
        {
            get { return Name; }
            set { Name = value; }
        }

        private Boolean Status;

        public Boolean STATUS
        {
            get { return Status; }
            set { Status = value; }
        }
    }
}