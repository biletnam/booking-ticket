﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class TicketViews
    {
        private string BusType;

        public string BUSTYPE
        {
            get { return BusType; }
            set { BusType = value; }
        }

        private string Bus_Number;

        public string BUS_NUMBER
        {
            get { return Bus_Number; }
            set { Bus_Number = value; }
        }

        private int Cus_Id;

        public int CUS_ID
        {
            get { return Cus_Id; }
            set { Cus_Id = value; }
        }
        

        private string CustomerName;

        public string CUSTOMERNAME
        {
            get { return CustomerName; }
            set { CustomerName = value; }
        }
        
        private string ParkingPlace;

        public string PARKINGPLACE
        {
            get { return ParkingPlace; }
            set { ParkingPlace = value; }
        }

        private DateTime StartDate;

        public DateTime STARTDATE
        {
            get { return StartDate; }
            set { StartDate = value; }
        }


        private string StartPlace;

        public string STARTPLACE
        {
            get { return StartPlace; }
            set { StartPlace = value; }
        }

        private string EndPlace;

        public string ENDPLACE
        {
            get { return EndPlace; }
            set { EndPlace = value; }
        }

        private int T_Id;

        public int T_ID
        {
            get { return T_Id; }
            set { T_Id = value; }
        }


        private string StartTime;

        public string STARTTIME
        {
            get { return StartTime; }
            set { StartTime = value; }
        }

        private string EndTime;

        public string ENDTIME
        {
            get { return EndTime; }
            set { EndTime = value; }
        }

        private int SeatNumber;

        public int SEATNUMBER
        {
            get { return SeatNumber; }
            set { SeatNumber = value; }
        }

        private double Price;

        public double PRICE
        {
            get { return Price; }
            set { Price = value; }
        }

        private bool StatusReturn;

        public bool STATUSRETURN
        {
            get { return StatusReturn; }
            set { StatusReturn = value; }
        }

        private bool StatusIssue;

        public bool STATUSISSUE
        {
            get { return StatusIssue; }
            set { StatusIssue = value; }
        }
        
        
    }
}