﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Entity
{
    public class Diminish
    {
        public Diminish()
        { 
        
        }

        private int DI_Id;

        public int DI_ID
        {
            get { return DI_Id; }
            set { DI_Id = value; }
        }
        private int DayNumberBefor;

        public int DayNumberBefor1
        {
            get { return DayNumberBefor; }
            set { DayNumberBefor = value; }
        }


        private int DiminishPercent;

        public int DiminishPercent1
        {
            get { return DiminishPercent; }
            set { DiminishPercent = value; }
        }

        
    }
}