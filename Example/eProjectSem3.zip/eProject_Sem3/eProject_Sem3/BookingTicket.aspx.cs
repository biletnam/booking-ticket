﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObjectLayer;
using Entity;
namespace OBTRS
{
    public partial class BookingTicket : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
          
            ShowResult();
        }
       
        public Double GePrice(double PRice)
        {
            return pk.GetTotalPrice(PRice);

        }
        FindPacket pk;
        List<SearchRouteInfomation> Lsri;
        public void ShowResult()
        {
            pk = (FindPacket)Session["Fpk"];
            Label10.Text = String.Format("Senior citizen: {0}\t Adult:{1} \t Child:{2}\t Infan:{3}", pk.Senior, pk.Adult, pk.Child, pk.Infan);
            Lsri = new List<SearchRouteInfomation>();
            Bol_FindRoute bFR = new Bol_FindRoute();
            Lsri = bFR.FindRouteResult(pk);
            if (Lsri.Count > 0)
            {
                Rp.DataSource = Lsri;
                Rp.DataBind();
                Session["BookingInfor"] = Lsri;
                Session["Fpk"]=pk;
            }

        }
    }
}