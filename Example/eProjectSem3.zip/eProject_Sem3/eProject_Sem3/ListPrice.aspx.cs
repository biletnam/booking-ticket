﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObjectLayer;
namespace eProject_Sem3
{
    public partial class ListPrice : System.Web.UI.Page
    {
        Bol_Route BRo;
        protected void Page_Load(object sender, EventArgs e)
        {
            BRo = new Bol_Route();
            if (!IsPostBack)
            {
                RP.DataSource = BRo.SelectAllRoute();
                RP.DataBind();
            }
        }

        protected void RP_ItemCreated(object sender, RepeaterItemEventArgs e)
        {

            RepeaterItem rp = (RepeaterItem)e.Item;
            if (rp.ItemType == ListItemType.Item || rp.ItemType == ListItemType.AlternatingItem)
            {

                DropDownList drBt = rp.FindControl("DrBusType") as DropDownList;
                drBt.AutoPostBack = true;
                drBt.SelectedIndexChanged += new EventHandler(drBt_SelectedIndexChanged);
                DropDownList drSales = rp.FindControl("DrSale") as DropDownList;
                drSales.AutoPostBack = true;
                drSales.SelectedIndexChanged += new EventHandler(drSales_SelectedIndexChanged);
            }
        }

        protected void drBt_SelectedIndexChanged(object sender, EventArgs e)
        {

            DropDownList drBt = (DropDownList)sender;
            Label PWT = drBt.Parent.FindControl("PWT") as Label;
            Label Price = drBt.Parent.FindControl("Price") as Label;
            double pr = Convert.ToDouble(PWT.Text);
            double TTP = pr + pr * (Convert.ToDouble(drBt.SelectedValue) / 100);
            Price.Text = "" + TTP;
            
        }

        protected void drSales_SelectedIndexChanged(object sender, EventArgs e)
        {

            DropDownList drSales = (DropDownList)sender;

            DropDownList dr = drSales.Parent.FindControl("DrBusType") as DropDownList;

            Label lblPrice = drSales.Parent.FindControl("Price") as Label;

            Label PWT = drSales.Parent.FindControl("PWT") as Label;

            double pr = Convert.ToDouble(PWT.Text);
            double TTP = pr + pr * (Convert.ToDouble(dr.SelectedValue) / 100);
            double TotalPR = TTP - TTP * (Convert.ToDouble(drSales.SelectedValue) / 100);
            lblPrice.Text = TotalPR.ToString();

        }

    }
}