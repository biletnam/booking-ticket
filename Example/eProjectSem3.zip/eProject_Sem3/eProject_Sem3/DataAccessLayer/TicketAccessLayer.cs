﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer.Library;
using Entity;
using System.Data;

namespace DataAccessLayer
{
    public class TicketAccessLayer:ExecuteDataBase
    {
        public TicketAccessLayer()
        {

        }

        private Ticket ConvetDataRowToTicket(DataRow item)
        {
            Ticket tk = new Ticket();
            tk.CUS_ID = Convert.ToInt32(item["T_id"]);
            tk.RETURN = Convert.ToBoolean(item["Return"]);
            tk.STATUS = Convert.ToBoolean(item["Status"]);
            tk.PRICE = Convert.ToDouble(item["Price"]);
            return tk;
        }


        //Ham gan bang vao list doi tuong
        private List<Ticket> GetListFromDataTable(DataTable dt)
        {
            List<Ticket> L_tk = new List<Ticket>();

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    L_tk.Add(ConvetDataRowToTicket(item));
                }

            }
            return L_tk;
        }

        //Ham update Ticket.Status by ID
        public int UpdateTicket(Ticket tk)
        {
            IDataParameter[] idp = new IDataParameter[2];
            idp[0] = createParameter("@T_Id", tk.T_ID);
            idp[1] = createParameter("@Status", tk.STATUS);
            return ExecuteNonQuery("ProcUpdateTicketbyID", idp);

        }
    }
}