﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using DataAccessLayer.Library;
using Entity;

namespace DataAccessLayer
{
    public class CustomerAccessLayer : ExecuteDataBase
    {
        DataTable dt;
        public CustomerAccessLayer()
        {

        }

        //Ham chuyen 1 ban ghi thanh 1 doi tuong
        private Customers ConvetDataRowToCustomer(DataRow item)
        {
            Customers cus = new Customers();
            cus.CUS_ID = Convert.ToInt32(item["Cus_id"]);
            cus.FIRSTNAME = item["FirstName"].ToString();
            cus.LASTNAME = item["LastName"].ToString();
            cus.ADDRESS = item["Address"].ToString();
            cus.EMAIL = item["Email"].ToString();
            cus.REGISTERDATE = Convert.ToDateTime(item["RegisterDate"]);
            cus.PHONENUMBER = item["PhoneNumber"].ToString();
            cus.STATUS = Convert.ToBoolean(item["Status"]);
            return cus;
        }

       
        //Ham gan bang vao list doi tuong
        private List<Customers> GetListFromDataTable(DataTable dt)
        {
            List<Customers> L_Cus = new List<Customers>();

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    L_Cus.Add(ConvetDataRowToCustomer(item));
                }

            }
            return L_Cus;
        }

        //ham tim kiem
        public List<Customers> FindBy(string column, string value)
        {
            IDataParameter[] idp = new IDataParameter[3];
            idp[0] = createParameter("@Table", "Customers");
            idp[1] = createParameter("@Column", column);
            idp[2] = createParameter("@Value", value);
            DataTable dt = ExecuteDataTable("Find", idp);
            return GetListFromDataTable(dt);
        }

        #region Select
        //Select all customer
        public List<Customers> SelectAllCustomer()
        {
            dt = ExecuteDataTable("SelectAllCustomer", null);
            return GetListFromDataTable(dt);
        }

        #endregion

        #region delete
        //Delete a customer
        public List<Customers> deleteCus(Customers cus)
        {
            DataTable dt = ExecuteDataTable("DeleteCustomer", createParameter("@Cus_Id", cus.CUS_ID));
            return GetListFromDataTable(dt);
        }
        #endregion

        #region update
        //Ham cap nhat 1 customer
        public int UpdateCustomer(Customers cus)
        {
            IDataParameter[] idp = new IDataParameter[8];
            idp[0] = createParameter("@Cus_Id", cus.CUS_ID);
            idp[1] = createParameter("@FirstName", cus.FIRSTNAME);
            idp[2] = createParameter("@LastName", cus.LASTNAME);
            idp[3] = createParameter("@Address", cus.ADDRESS);
            idp[4] = createParameter("@Email", cus.EMAIL);
            idp[5] = createParameter("@RegisterDate", cus.REGISTERDATE);
            idp[6] = createParameter("@PhoneNumber", cus.PHONENUMBER);
            idp[7] = createParameter("@Status", cus.STATUS);
            return ExecuteNonQuery("UpdateCustomer", idp);

        }
        #endregion
        #region Booking
        public int BookingTicket(Customers Cus, int Sa_ID, int P_ID)
        {
            IDataParameter[] idp = new IDataParameter[8];
            idp[0] = createParameter("@FIRSTNAME", Cus.FIRSTNAME);
            idp[1] = createParameter("@LASTNAME", Cus.LASTNAME);
            idp[2] = createParameter("@ADDRESS", Cus.ADDRESS);
            idp[3] = createParameter("@EMAIL", Cus.EMAIL);
            idp[4] = createParameter("@REGISTERDATE", Cus.REGISTERDATE);
            idp[5] = createParameter("@PHONENUMBER", Cus.PHONENUMBER);
            idp[6] = createParameter("@Sa_ID", Sa_ID);
            idp[7] = createParameter("@P_ID", P_ID);
            return ExecuteNonQuery("BookingTicket", idp);
        }

        #endregion
    }
}