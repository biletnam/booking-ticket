﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Text;
using System.Data;
using Entity;
using System.Data.SqlClient;
using DataAccessLayer.Library;

namespace DataAccessLayer
{
    public class AdminAccessLayer:ExecuteDataBase
    {
        DataTable data;
        public AdminAccessLayer()
        { 
            
        }
        private Admin ConvetDataRowToAdmin(DataRow item)
        {
            Admin nae = new Admin();
            nae.A_id = Convert.ToInt32(item["A_Id"]);
            nae.Username = item["UserName"].ToString();
            nae.pass = item["Pass"].ToString();
            nae.Fullname = item["FullName"].ToString();
            nae.address = item["Address"].ToString();
            nae.phoneNumber = item["PhoneNumber"].ToString();
            return nae;
        }
        private List<Admin> GetListFromDataTable(DataTable data)
        {
            List<Admin> L_Admin = new List<Admin>();

            if (data.Rows.Count > 0)
            {
                foreach (DataRow item in data.Rows)
                {
                    L_Admin.Add(ConvetDataRowToAdmin(item));
                }

            }
            return L_Admin;
        }

        public int CheckAdmin(Admin ad)
        {
            int i = 0;
            data = new DataTable();
            data = ExecuteDataTable("SelectAdminPass", createParameter("@Pass", ad.pass));
            if (data.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }

        public List<Admin> SelectAdminPass(Admin adm)
        {
            data = ExecuteDataTable("SelectAdminPass", createParameter("",adm.pass));
            return GetListFromDataTable(data);
        }

        public List<Admin> SelectAllAdmin()
        {
            data = ExecuteDataTable("SelectAdmin", null);
            return GetListFromDataTable(data);
        }
        public int InsertAdmin(String UserName, String Pass, String FullName, String Address, String PhoneNumber)
        {
            IDataParameter[] id = new IDataParameter[5];
            id[0] = createParameter("@UserName", UserName);
            id[1] = createParameter("@Pass", Pass);
            id[2] = createParameter("@FullName", FullName);
            id[3] = createParameter("@Address", Address);
            id[4] = createParameter("@PhoneNumber", PhoneNumber);
            return ExecuteNonQuery("InsertAdmin", id);
        }
        public int UpdateAdmin(String UserName, String Pass, String FullName, String Address, String PhoneNumber, int id)
        {
            IDataParameter[] idm = new IDataParameter[6];
            idm[0] = createParameter("@UserName", UserName);
            idm[1] = createParameter("@Pass", Pass);
            idm[2] = createParameter("@FullName", FullName);
            idm[3] = createParameter("@Address", Address);
            idm[4] = createParameter("@PhoneNumber", PhoneNumber);
            idm[5] = createParameter("@id", id);
            return ExecuteNonQuery("UpdateAdminID", idm);
        }
        public int DeleteAdmin(int id)
        {
            return ExecuteNonQuery("DeleteAdminID", createParameter("@id", id));
        }
        public List<Admin> SelectAdminID(int id)
        {
            data = ExecuteDataTable("SelectAdminID", createParameter("@id", id));
            return GetListFromDataTable(data);
        }
        public List<Admin> SelectAdminName(string UserName)
        {
            data = ExecuteDataTable("SelectAdminName", createParameter("@UserName", UserName));
            return GetListFromDataTable(data);
        }
        public List<Admin> SelectAdminFullName(string FullName)
        {
            data = ExecuteDataTable("SELECTADMINFULLNAME", createParameter("@FULLNAME", FullName));
            return GetListFromDataTable(data);
        }
        public List<Admin> SelectAdminAddress(string Address)
        {
            data = ExecuteDataTable("SELECTADMINADDRESS", createParameter("@ADDRESS", Address));
            return GetListFromDataTable(data);
        }
        public List<Admin> SelectAdminPhoneNumber(string Phone)
        {
            data = ExecuteDataTable("SELECTADMINPHONENUMBER", createParameter("@PHONENUMBER", Phone));
            return GetListFromDataTable(data);
        }
        public List<Admin> SelectAdminPassWord(string Pass)
        {
            data = ExecuteDataTable("SELECTADMINPASSWORD", createParameter("@Pass", Pass));
            return GetListFromDataTable(data);
        }
        

    }

}