﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using DataAccessLayer.Library;
using Entity;

namespace DataAccessLayer
{
    public class TicketReturnAccessLayer :ExecuteDataBase
    {

        private TicketReturn ConvertDataRowToTicketReturn(DataRow dr)
        {
            TicketReturn tr = new TicketReturn();
            tr.TR_ID = Convert.ToInt32(dr["TR_Id"]);
            tr.RETURNDATE = Convert.ToDateTime(dr["RetuneDate"]);
            tr.DI_ID = Convert.ToInt32(dr["DI_Id"]);
            tr.RETURNPRICE = Convert.ToInt32(dr["ReturnPrice"]);
            return tr;
        }

        private List<TicketReturn> GetListFromDataTable(DataTable dt)
        {
            List<TicketReturn> lc = new List<TicketReturn>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dtr in dt.Rows)
                {
                    lc.Add(ConvertDataRowToTicketReturn(dtr));
                }
            }
            return lc;
        }

        public List<TicketReturn> SelectAllTicketReturn()
        {
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectAllTicketReturn", null);
            return GetListFromDataTable(dt);
        }
        public List<TicketReturn> SelectTicketReturnByID(TicketReturn tic)
        {
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectTicketReturnByID", createParameter("@TR_Id", tic.DI_ID));
            return GetListFromDataTable(dt);
        }

        public int CheckTicketReturnExistByID(TicketReturn tic)
        {
            int i = 0;
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectAllTicketReturn", createParameter("@TR_Id", tic.DI_ID));
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }

        public int InsertTicketReturn(TicketReturn tkrt)
        {
            IDataParameter[] idp = new IDataParameter[4];
            idp[0] = createParameter("@TR_Id", tkrt.TR_ID);
            idp[1] = createParameter("@RetuneDate", tkrt.RETURNDATE);
            idp[2] = createParameter("@DI_Id", tkrt.DI_ID);
            idp[3] = createParameter("@ReturnPrice", tkrt.RETURNPRICE);
            return ExecuteNonQuery("InsertTicketReturn", idp);
        }
        public int DeleteTicketReturnByID(TicketReturn tic)
        {
            return ExecuteNonQuery("DeleteTicketReturn", createParameter("@TR_Id", tic.TR_ID));
        }
    }
}