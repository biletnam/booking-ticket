﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer.Library;
using Entity;
using System.Data;
namespace DataAccessLayer
{
    public class BusAccessLayer : ExecuteDataBase
    {
        public BusAccessLayer()
        {

        }

        #region select
        public List<Bus> SelectAllBus()
        {

            DataTable dt = ExecuteDataTable("SelectAllBus", null);
            List<Bus> lb = ConvertDataTableToList(dt);
            return lb;
        }

        private static List<Bus> ConvertDataTableToList(DataTable dt)
        {
            List<Bus> lb = new List<Bus>();

            foreach (DataRow item in dt.Rows)
            {
                Bus bu = ConvertDataRowToBus(item);
                lb.Add(bu);
            }
            return lb;
        }

        private static Bus ConvertDataRowToBus(DataRow item)
        {
            Bus bu = new Bus();
            bu.Bus_Number = item["Bus_Number"].ToString();
            bu.Seat = Convert.ToInt32(item["Seat"]);
            bu.BT_ID = Convert.ToInt32(item["BT_ID"]);
            bu.Status = Convert.ToBoolean(item["Status"]);
            return bu;
        }
        #endregion
        #region Insert

        public int InsertBus(Bus b)
        {
            IDataParameter[] idp = new IDataParameter[4];
            idp[0] = createParameter("@Bus_number", b.Bus_Number);
            idp[1] = createParameter("@Seat", b.Seat);
            idp[2] = createParameter("@BT_Id", b.BT_ID);
            idp[3] = createParameter("@Status", b.Status);
            return ExecuteNonQuery("InsertBus", idp);
        }
        #endregion
        #region update

        public int UpdateBusByBusNumber(Bus b) {
            IDataParameter[] idp = new IDataParameter[4];
            idp[0] = createParameter("@Bus_number", b.Bus_Number);
            idp[1] = createParameter("@Seat", b.Seat);
            idp[2] = createParameter("@BT_Id", b.BT_ID);
            idp[3] = createParameter("@Status", b.Status);
            return ExecuteNonQuery("UpdateBusByBusNumber", idp);
        }
        #endregion
    }
}