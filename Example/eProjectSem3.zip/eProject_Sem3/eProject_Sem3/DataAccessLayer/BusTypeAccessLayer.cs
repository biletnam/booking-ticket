﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using  DataAccessLayer.Library;
using Entity;
namespace DataAccessLayer
{
    public class BusTypeAccessData : ExecuteDataBase
    {
        DataTable dt;
        public BusTypeAccessData()
        {

        }
        private BusType ConvertDataRowToBusType(DataRow dr)
        {
            BusType bt = new BusType();
            bt.BT_ID = Convert.ToInt32(dr["BT_Id"]);
            bt.Name = dr["Name"].ToString();
            bt.Description = dr["Description"].ToString();
            bt.Price = Convert.ToInt32(dr["Price"]);
            bt.Status = Convert.ToBoolean(dr["Status"]);
            return bt;
        }
        private List<BusType> GetListFromDataTable(DataTable dt)
        {
            List<BusType> lbt = new List<BusType>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dtr in dt.Rows)
                {
                    lbt.Add(ConvertDataRowToBusType(dtr));
                }
            }
            return lbt;
        }
        #region SelectBusType
        public List<BusType> SelectAllBusType()
        {
            DataTable dr = new DataTable();
            dt = ExecuteDataTable("SelectAllBusType", null);
            return GetListFromDataTable(dt);
        }
        public List<BusType> SelectBusTypeByID(BusType bt)
        {
            DataTable dr = new DataTable();
            dr = ExecuteDataTable("SelectBusTypeByID", createParameter("@BT_ID", bt.BT_ID));
            return GetListFromDataTable(dr);
        }
        public List<BusType> SelectBusTypeByName(BusType bt)
        {
            DataTable dr = new DataTable();
            dr = ExecuteDataTable("SelectBusTypeByName", createParameter("@Name", bt.Name));
            return GetListFromDataTable(dr);
        }
        public int CheckBusTypeExistByID(BusType bt)
        {
            int i = 0;
            dt = new DataTable();
            dt = ExecuteDataTable("SelectBusTypeByID", createParameter("@BT_Id", bt.BT_ID));
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }
        public int CheckBusTypeExistByName(BusType bt)
        {
            int i = 0;
            dt = new DataTable();
            dt = ExecuteDataTable("SelectBusTypeByName", createParameter("@Name", bt.Name));
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }
        #endregion

        #region InsertBusType
        public int InsertBusType(BusType bt)
        {
            IDataParameter[] idp = new IDataParameter[4];
            idp[0] = createParameter("@Name", bt.Name);
            idp[1] = createParameter("@Description", bt.Description);
            idp[2] = createParameter("@Price", bt.Price);
            idp[3] = createParameter("@Status", bt.Status);
            return ExecuteNonQuery("InsertBusType",idp);
        }
        #endregion

        #region UpdateBusType  
        public int UpdateBusTypeByID(BusType bt)
        {
            IDataParameter[] idp = new IDataParameter[5];
            idp[0] = createParameter("@BT_Id", bt.BT_ID);
            idp[1] = createParameter("@Name", bt.Name);
            idp[2] = createParameter("@Description", bt.Description);
            idp[3] = createParameter("@Price", bt.Price);
            idp[4] = createParameter("@Status",bt.Status);
            return ExecuteNonQuery("UpdateBusTypeByID",idp);
        }

        public int UpdateBusTypeByName(BusType bt)
        {
            IDataParameter[] idp = new IDataParameter[4];            
            idp[0] = createParameter("@Name", bt.Name);
            idp[1] = createParameter("@Description", bt.Description);
            idp[2] = createParameter("@Price", bt.Price);
            idp[3] = createParameter("@Status", bt.Status);
            return ExecuteNonQuery("UpdateBusTypeByName",idp);
        }
        #endregion

        #region DeleteBusType
        public int DeleteBusTypeByID(BusType bt)
        {
            return ExecuteNonQuery("DeleteBusTypeByID", createParameter("@BT_Id", bt.BT_ID));
        }
        public int DeleteBusTypeByName(BusType bt)
        {
            return ExecuteNonQuery("DeleteBusTypeByName", createParameter("@Name", bt.Name));
        }
        #endregion
       

    }
}

