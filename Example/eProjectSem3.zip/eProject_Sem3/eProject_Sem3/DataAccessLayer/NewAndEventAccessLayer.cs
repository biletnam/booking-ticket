﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer.Library;
using Entity;


namespace DataAccessLayer
{
    public class NewAndEventsAccessLayer:ExecuteDataBase
    {
        DataTable dt;
        public NewAndEventsAccessLayer()
        { 
        
        }
        private NewAndEvent ConvetDataRowToNewAndEvent(DataRow item)
        {
            NewAndEvent nae = new NewAndEvent();
            nae.NE_Id = Convert.ToInt32(item["NE_Id"]);
            nae.Title = item["Title"].ToString();
            nae.Content = item["Content"].ToString();
            nae.Author = item["Author"].ToString();
            nae.Date = Convert.ToDateTime(item["Date"]);
            nae.Status = Convert.ToBoolean(item["Status"]);
            return nae;
        }
        //private List<String> GetColumn(DataTable data)
        //{
        //    List<String> str = new List<string>();
        //    foreach (DataColumn item in data.Columns)
        //    {
        //        str.Add(item.ColumnName);
        //    }
        //    return str;
        //}

        private List<NewAndEvent> GetListFromDataTable(DataTable dt)
        {
            List<NewAndEvent> L_New = new List<NewAndEvent>();

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    L_New.Add(ConvetDataRowToNewAndEvent(item));
                }

            }
            return L_New;
        }

        public List<NewAndEvent> SelectNewAndEvent()
        {
            dt = ExecuteDataTable("SelectNewAndEvent",null);
            return GetListFromDataTable(dt);
        }
        public List<NewAndEvent> selectByID(int id)
        {
            dt= ExecuteDataTable("SelectbyID", createParameter("@id", id));
            return GetListFromDataTable(dt);
        }
        public List<NewAndEvent> SelectTitleNewandEvent(string title)
        {
            dt= ExecuteDataTable("SelectTitleNewAndEvent", createParameter("@Title", title));
            return GetListFromDataTable(dt);
        }
        public int InsertNewAndEvent(String Title, String Content, String Author,DateTime Date,Boolean Status)
        {
            IDataParameter[] id =new IDataParameter[5];
           
            id[0] = createParameter("@Title",Title);
            id[1] = createParameter("@Content",Content);
            id[2] = createParameter("@Author",Author);
            id[3] = createParameter("@Date", Date);
            id[4] = createParameter("@Status", Status);
            return ExecuteNonQuery("InsertNewAndEvent", id);
        }
        public int UpdateNewAndEvent(int id,String Title, String Content, String Author, DateTime Date, Boolean Status)
        {
            IDataParameter[] idm = new IDataParameter[6];
            idm[0] = createParameter("@Title", Title);
            idm[1] = createParameter("@Content", Content);
            idm[2] = createParameter("@Author", Author);
            idm[3] = createParameter("@Date", Date);
            idm[4] = createParameter("@Status", Status);
            idm[5] = createParameter("@id", id);
            return ExecuteNonQuery("UpdateNewAndEventID", idm);            
        }

        public int DeleteNewAndEventID(int id)
        {
            return ExecuteNonQuery("DeleteNewAndEventID",createParameter("@id",id));
        }
        public List<NewAndEvent> SelectNewandEventContent(string content)
        {
            dt= ExecuteDataTable("SELECTNEWANDEVENTCONTENT", createParameter("@CONTENT", content));
            return GetListFromDataTable(dt);
        }
        public List<NewAndEvent> SelectNewandEventAuthor(string author)
        {
            dt = ExecuteDataTable("SELECTNEWANDEVENTAUTHOR", createParameter("@AUTHOR", author));
            return GetListFromDataTable(dt);
        }
        public List<NewAndEvent> SelectNewandEventDate(DateTime date)
        {
            dt = ExecuteDataTable("SELECTNEWANDEVENTDATE", createParameter("@DATE", date));
            return GetListFromDataTable(dt);
        }
        public List<NewAndEvent> SelectNewandEventStatus(Boolean status)
        {
            dt = ExecuteDataTable("SELECTNEWANDEVENTSTATUS", createParameter("@STATUS", status));
            return GetListFromDataTable(dt);
        }

    }
}