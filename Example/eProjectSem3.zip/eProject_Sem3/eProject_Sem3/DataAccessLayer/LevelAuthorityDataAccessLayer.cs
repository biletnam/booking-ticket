﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using DataAccessLayer.Library;
using Entity;

namespace DataAccessLayer
{
    public class LevelAuthorityDataAccessLayer : ExecuteDataBase
    {
        public LevelAuthorityDataAccessLayer()
        { }

        private LevelAuthority ConvertDataRowToLevelAuthority(DataRow item)
        {
            LevelAuthority la = new LevelAuthority();
            la.LV_ID = Convert.ToInt32(item["LV_Id"]);
            la.NAME = item["Name"].ToString();
            la.STATUS = Convert.ToBoolean(item["Status"]);
            return la;
        }

        private List<LevelAuthority> getListFromDataTable(DataTable dt)
        {
            List<LevelAuthority> lla = new List<LevelAuthority>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    lla.Add(ConvertDataRowToLevelAuthority(item));
                }
            }
            return lla;
        }
        public List<LevelAuthority> getAllLevel()
        {
            DataTable dt = ExecuteDataTable("SelectAllLevel_Authority", null);
            return getListFromDataTable(dt);
        }

        public List<LevelAuthority> getLevelbyID(int ID)
        {
            DataTable dt = ExecuteDataTable("SelectLevel_Authority", createParameter("@LV_Id", ID));
            return getListFromDataTable(dt);
        }

        public List<LevelAuthority> getLevelbyName(String Name)
        {
            DataTable dt = ExecuteDataTable("SelectLevel_AuthoritybyName", createParameter("@Name", Name));
            return getListFromDataTable(dt);
        }

        public int InsertLevel(string Name, Boolean Status)
        {
            IDataParameter[] id = new IDataParameter[2];
            id[0] = createParameter("@Name", Name);
            id[1] = createParameter("@Status", Status);
            return ExecuteNonQuery("InsertLevel_Authority", id);
        }

        public int DeleteLevel(int ID)
        {
            return ExecuteNonQuery("DeleteLevel_Authority", createParameter("@LV_Id", ID));
        }

        public int UpdateLevel(int ID, string Name, Boolean Status)
        {
            IDataParameter[] id = new IDataParameter[2];
            id[0] = createParameter("@LV_Id", ID);
            id[1] = createParameter("@Name", Name);
            id[2] = createParameter("@Status", Status);
            return ExecuteNonQuery("UpdateLevel_Authority", id);
        }
    }
}