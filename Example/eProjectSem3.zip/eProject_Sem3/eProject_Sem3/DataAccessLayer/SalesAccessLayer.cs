﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using DataAccessLayer.Library;
using Entity;
namespace DataAccessLayer
{
    public class SalesAccessLayer : ExecuteDataBase
    {
        DataTable dt;
        #region SelectSales
        public SalesAccessLayer()
        { 
            
        }
        private Sales ConvetDataRowToSales(DataRow item)
        {
            Sales nae = new Sales();
            nae.Sa_ID = Convert.ToInt32(item["Sa_Id"]);
            nae.Name = item["Name"].ToString();
            nae.Rate = Convert.ToInt32(item["Rate"]);
            nae.Status = Convert.ToBoolean(item["Status"]);
            return nae;
        }
        private List<Sales> GetListFromDataTable(DataTable dt)
        {
            List<Sales> L_Sa = new List<Sales>();

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    L_Sa.Add(ConvetDataRowToSales(item));
                }

            }
            return L_Sa;
        }


        public List<Sales> GetAllSales()
        {
            //DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectAllSales", null);
            return GetListFromDataTable(dt);
        }
        public List<Sales> GetSalesByID(Sales id)
        {
            //DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectSalesByID", createParameter("@Sa_Id", id.Sa_ID));
            return GetListFromDataTable(dt);
        }
        public List<Sales> GetSalesByName(Sales name)
        {
            //DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectSalesByName", createParameter("@Name", name.Name));
            return GetListFromDataTable(dt);
        }
        public int CheckSalesExistByID(Sales id)
        {
            int i=0;
            dt = new DataTable();
            dt = ExecuteDataTable("SelectSalesByID",createParameter("@Sa_Id",id.Sa_ID));
            if(dt.Rows.Count ==0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }
        public int CheckSalesExistByName(Sales name)
        {
            int i = 0;
            dt = new DataTable();
            dt = ExecuteDataTable("SelectSalesByName", createParameter("@Name",name.Name));
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }
        #endregion
        #region InsertSales
        public int InsertSales(Sales sl)
        {
            IDataParameter[] idp = new IDataParameter[3];
            idp[0] = createParameter("@Name", sl.Name);
            idp[1] = createParameter("@Rate", sl.Rate);
            idp[2] = createParameter("@Status", sl.Status);
            return ExecuteNonQuery("InsertSales",idp);
        }
        #endregion

        #region UpdateSales
        public int UpdateSalesByID(Sales sl)
        {
            IDataParameter[] idp = new IDataParameter[4];
            idp[0] = createParameter("@Sa_Id", sl.Sa_ID);
            idp[1] = createParameter("@Name", sl.Name);           
            idp[2] = createParameter("@Rate", sl.Rate);
            idp[3] = createParameter("@Status", sl.Status);
            return ExecuteNonQuery("UpdateSalesByID",idp);
        }

        public int UpdateSalesByName(Sales sl)
        {
            IDataParameter[] idp = new IDataParameter[3];
            idp[0] = createParameter("@Name", sl.Name);
            idp[1] = createParameter("@Rate", sl.Rate);
            idp[2] = createParameter("@Status", sl.Status);
            return ExecuteNonQuery("UpdateSalesByName",idp);
        }
        #endregion

        #region DeleteSales
        public int DeleteSalesByID(Sales id)
        {
            return ExecuteNonQuery("DeleteSalesByID", createParameter("@Sa_Id",id.Sa_ID));
        }

        public int DeleteSalesByName(Sales name)
        {
            return ExecuteNonQuery("DeleteSalesByName", createParameter("@Name", name.Name));
        }
        #endregion

    }
}
