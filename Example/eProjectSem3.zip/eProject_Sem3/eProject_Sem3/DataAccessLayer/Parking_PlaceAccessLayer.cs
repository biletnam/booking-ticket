﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Entity;
using DataAccessLayer.Library;

namespace  DataAccessLayer
{
    public class Parking_PlaceAccessLayer: ExecuteDataBase
    {
        DataTable dt;
        #region SelectParking_Place

        private Parking_Place ConvetDataRowToParking_Place(DataRow item)
        {
            Parking_Place pl = new Parking_Place();
            pl.PP_ID = Convert.ToInt32(item["PP_Id"]);
            pl.Name = item["Name"].ToString();
            pl.Ci_ID = Convert.ToInt32(item["Ci_Id"]);
            pl.Status = Convert.ToBoolean(item["Status"]);
            return pl;
        }
        private List<Parking_Place> GetListFromDataTable(DataTable dt)
        {
            List<Parking_Place> pl = new List<Parking_Place>();
            
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    pl.Add(ConvetDataRowToParking_Place(item));
                }

            }
            return pl;
        }
        public List<Parking_Place> GetAllParking_Place()
        {
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectAllParking_Place",null);
            return GetListFromDataTable(dt);
        }

        public List<Parking_Place> GetParking_PlaceByID(Parking_Place pp)
        {
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectParking_PlaceByID", createParameter("@PP_Id", pp.PP_ID));
            return GetListFromDataTable(dt);
        }
        public List<Parking_Place> GetParking_PlaceByName(Parking_Place pp)
        {
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectParking_PlaceByName", createParameter("@Name", pp.Name));
            return GetListFromDataTable(dt);
        }
        public int CheckParking_PlaceExistByID(Parking_Place pp)
        {
            int i = 0;
            dt = new DataTable();
            dt = ExecuteDataTable("SelectParking_PlaceByID", createParameter("@PP_Id", pp.PP_ID));
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }

        public int CheckParking_PlaceExistByName(Parking_Place pp)
        {
            int i = 0;
            dt = new DataTable();
            dt = ExecuteDataTable("SelectParking_PlaceByName", createParameter("@Name", pp.Name));
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }
        #endregion
        #region UpdateParking_Place  
      
        public int UpdateParking_PlaceByID(Parking_Place pp)
        {
            IDataParameter[] idp = new IDataParameter[4];
            idp[0] = createParameter("@PP_Id", pp.PP_ID);
            idp[1] = createParameter("@Name", pp.Name);
            idp[2] = createParameter("@Ci_Id", pp.Ci_ID);
            idp[3] = createParameter("@Status", pp.Status);
            return ExecuteNonQuery("UpdateParking_PlaceByID", idp);
        }
        public int UpdateParking_PlaceByName(Parking_Place pp)
        {
            IDataParameter[] idp = new IDataParameter[3];            
            idp[0] = createParameter("@Name", pp.Name);
            idp[1] = createParameter("@Ci_Id", pp.Ci_ID);
            idp[2] = createParameter("@Status", pp.Status);
            return ExecuteNonQuery("UpdateParking_PlaceByName", idp);
        }
        #endregion

        #region InsertParking_Place
        public int InsertParking_Place(Parking_Place pp)
        {
            IDataParameter[] idp = new IDataParameter[3];
            idp[0] = createParameter("@Name", pp.Name);
            idp[1] = createParameter("@Ci_Id", pp.Ci_ID);
            idp[2] = createParameter("@Status", pp.Status);
            return ExecuteNonQuery("InsertParking_Place",idp);
        }
        #endregion
        
        #region DeleteParking_Place
        public int DeleteParking_PlaceByID(Parking_Place pp)
        {
            return ExecuteNonQuery("DeleteParking_PlaceByID", createParameter("@PP_Id", pp.PP_ID));
        }
        public int DeleteParking_PlaceByName(Parking_Place pp)
        {
            return ExecuteNonQuery("DeleteParking_PlaceByName", createParameter("@Name", pp.Name));
        }
        
        #endregion
    }
}
