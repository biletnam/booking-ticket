﻿using System;
using System.Collections.Generic;
using System.Web;
using Entity;
using DataAccessLayer.Library;
using System.Data;
namespace DataAccessLayer
{
    public class FindRouteInfomationAccessLayer : ExecuteDataBase
    {
        public FindRouteInfomationAccessLayer()
        {

        }
        private SearchRouteInfomation ConvetDataRowToPlan(DataRow item)
        {
            SearchRouteInfomation srt = new SearchRouteInfomation();
            srt.Bus_Number = Convert.ToString(item["Bus_Number"]);

            srt.Empty_Seats = Convert.ToInt32(item["Empty_Seats"]);

            srt.StartTime = Convert.ToString(item["StartTime"]);

            srt.EndTime = Convert.ToString(item["EndTime"]);

            srt.Bus_Type = Convert.ToString(item["Bus_Type"]);

            srt.StartDate = Convert.ToDateTime(item["StartDate"]);

            srt.StartPlace = Convert.ToString(item["StartPlace"]);

            srt.EndPlace = Convert.ToString(item["EndPlace"]);

            srt.ParkingPlace = Convert.ToString(item["ParkingPlace"]);

            srt.Price = Convert.ToDouble(item["Price"]);

            srt.P_ID = Convert.ToInt32(item["P_ID"]);

            return srt;
        }
        private List<SearchRouteInfomation> GetListFromDataTable(DataTable dt)
        {
            List<SearchRouteInfomation> L_Sroute = new List<SearchRouteInfomation>();

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    L_Sroute.Add(ConvetDataRowToPlan(item));
                }

            }
            return L_Sroute;
        }
        public List<SearchRouteInfomation> FindRouteResult(FindPacket pk)
        {
            IDataParameter[] idp = new IDataParameter[4];
            idp[0] = createParameter("@BusType", pk.BusType);

            idp[1] = createParameter("@StartPlace", pk.StartPlace);

            idp[2] = createParameter("@EndPlace", pk.EndPlace);

            idp[3] = createParameter("@StartDate", pk.StartDate);

            DataTable dt = ExecuteDataTable("GetFindRouteInformation", idp);
            return GetListFromDataTable(dt);
        }
    }
}