﻿using System;
using System.Collections.Generic;
using System.Web;
using Entity;
using System.Data;
using DataAccessLayer.Library;
namespace DataAccessLayer
{
    public class RouteAccessLayer : ExecuteDataBase
    {
        public RouteAccessLayer()
        {
                
        }
        private Route ConvetDataRowToPlan(DataRow item)
        {
            Route rt = new Route();
            rt.Rou_ID = Convert.ToInt32(item["Rou_ID"]);
            rt.Name = Convert.ToString(item["Name"]);
            rt.StartDate = Convert.ToDateTime(item["StartDate"]);
            rt.StartPlace = Convert.ToInt32(item["StartPlace"]);
            rt.EndPlace = Convert.ToInt32(item["EndPlace"]);
            rt.Description = Convert.ToString(item["Description"]);
            rt.Distance = Convert.ToInt32(item["Distance"]);
            rt.Status = Convert.ToBoolean(item["Status"]);
            rt.Price = Convert.ToDouble(item["Price"]);
            return rt;
        }
        private List<Route> GetListFromDataTable(DataTable dt)
        {
            List<Route> L_route = new List<Route>();

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    L_route.Add(ConvetDataRowToPlan(item));
                }

            }
            return L_route;
        }
        #region Select
        #region Select ALL
        public List<Route> SelectAllRoute()
        {
            DataTable dt = ExecuteDataTable("SelectAllRoute", null);
            return GetListFromDataTable(dt);
        }

        #endregion
        #region Select By ID
        public List<Route> SelectRouteById(Route rt)
        {
            DataTable dt = ExecuteDataTable("SelectRouteById", createParameter("@Rou_Id", rt.Rou_ID));
            return GetListFromDataTable(dt);
        }

        #endregion
        #region Select By ID
        public List<Route> SelectRoutebyName(Route rt)
        {
            DataTable dt = ExecuteDataTable("SelectRoutebyName", createParameter("@Name", rt.Name));
            return GetListFromDataTable(dt);
        }

        #endregion
        #endregion
        #region Insert
        public int InsertRoute(Route r)
        {
            IDataParameter[] idp = new IDataParameter[8];
            idp[0] = createParameter("@Name", r.Name);
            idp[1] = createParameter("@StartPlace",r.StartPlace);
            idp[2] = createParameter("@EndPlace", r.EndPlace);
            idp[3] = createParameter("@Distance",r.Distance);
            idp[0] = createParameter("@StartDate", r.StartDate);
            idp[1] = createParameter("@Price", r.Price);
            idp[2] = createParameter("@Description", r.Description);
            idp[3] = createParameter("@Status", r.Status);
            return ExecuteNonQuery("InsertRoute", idp);
        }
        #endregion

        #region Update
        public int UpdateRouteById(Route r)
        {
            IDataParameter[] idp = new IDataParameter[9];
            idp[0] = createParameter("@Rou_Id", r.Rou_ID);
            idp[1] = createParameter("@Name", r.Name);
            idp[2] = createParameter("@StartPlace", r.StartPlace);
            idp[3] = createParameter("@EndPlace", r.EndPlace);
            idp[4] = createParameter("@Distance", r.Distance);
            idp[5] = createParameter("@StartDate", r.StartDate);
            idp[6] = createParameter("@Price", r.Price);
            idp[7] = createParameter("@Description", r.Description);
            idp[8] = createParameter("@Status", r.Status);
            return ExecuteNonQuery("InsertRoute", idp);
        }
       
        #endregion
        #region Delete
        public int DeleteRouteById(Route r)
        { 
            return ExecuteNonQuery("DeleteRouteById",createParameter("@Rou_Id",r.Rou_ID));
        }
        #endregion


    }
}