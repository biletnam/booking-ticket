﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using  DataAccessLayer.Library;
using  Entity;
namespace DataAccessLayer
{
    public class PlanAccessLayer:ExecuteDataBase
    {
        public PlanAccessLayer()
        {

        }
        private Plan ConvetDataRowToPlan(DataRow item)
        {
            Plan pl = new Plan();
            pl.P_ID = Convert.ToInt32(item["P_Id"]);
            pl.Rou_ID = Convert.ToInt32(item["Rou_Id"]);
            pl.BusNumber = item["Bus_Number"].ToString();
            pl.PP_ID = Convert.ToInt32(item["PP_Id"]);
            pl.TS_ID = Convert.ToInt32(item["TS_Id"]);
            pl.StartDate = Convert.ToDateTime(item["StartDate"]);
            return pl;
        }
        private List<Plan> GetListFromDataTable(DataTable dt)
        {
            List<Plan> L_plan = new List<Plan>();
            
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    L_plan.Add(ConvetDataRowToPlan(item));
                }

            }
            return L_plan;
        }
       
            #region Select ALL
            public List<Plan> SelectAllPlan()
            {
                DataTable dt = ExecuteDataTable("SelectPlanInformation", null);
                return GetListFromDataTable(dt);
            }
            
            #endregion

            #region Select
            public List<Plan> SelectPlanById(Plan pl)
            {
                DataTable dt = ExecuteDataTable("SelectPlanById", createParameter("@P_ID",pl.P_ID));
                return GetListFromDataTable(dt);
            }
            public List<Plan> SelectPlanByBus_Number(Plan pl)
            {
                DataTable dt = ExecuteDataTable("SelectPlanByBus_Number", createParameter("@Bus_Number", pl.BusNumber));
                return GetListFromDataTable(dt);
            }
            public List<Plan> SelectPlanByTS_Id(Plan pl)
            {
                DataTable dt = ExecuteDataTable("SelectPlanByTS_Id", createParameter("@TS_Id", pl.TS_ID));
                return GetListFromDataTable(dt);
            }

            public List<Plan> SelectPlanByStartDate(Plan pl)
            {
                DataTable dt = ExecuteDataTable("SelectPlanByStartDate", createParameter("@StartDate", pl.StartDate));
                return GetListFromDataTable(dt);
            }
            public List<Plan> SelectPlanByRou_Id(Plan pl)
            {
                DataTable dt = ExecuteDataTable("SelectPlanByRou_Id", createParameter("@Rou_Id", pl.Rou_ID));
                return GetListFromDataTable(dt);
            }
            public List<Plan> SelectPlanByPP_Id(Plan pl)
            {
                DataTable dt = ExecuteDataTable("SelectPlanByPP_Id", createParameter("@PP_Id", pl.PP_ID));
                return GetListFromDataTable(dt);
            }
            #endregion

            #region Insert
            public int InsertPlan(Plan p)
        {
            IDbDataParameter[] idb = new IDbDataParameter[5];
            idb[0] = createParameter("@Rou_Id", p.Rou_ID);
            idb[1] = createParameter("@PP_Id", p.PP_ID);
            idb[2] = createParameter("@Bus_Number", p.BusNumber);
            idb[3] = createParameter("@TS_Id",p.TS_ID);
            idb[4] = createParameter("@StartDate",p.StartDate);
            return ExecuteNonQuery("InsertPlan",idb);
        }
            #endregion


        #region Update
            public int UpdatePlanById(Plan p)
        {
            IDbDataParameter[] idb = new IDbDataParameter[6];
            idb[0] = createParameter("@P_Id", p.P_ID);
            idb[1] = createParameter("@Rou_Id", p.Rou_ID);
            idb[2] = createParameter("@PP_Id", p.PP_ID);
            idb[3] = createParameter("@Bus_Number", p.BusNumber);
            idb[4] = createParameter("@TS_Id", p.TS_ID);
            idb[5] = createParameter("@StartDate", p.StartDate);
            return ExecuteNonQuery("UpdatePlanById", idb);
        }
        #endregion

        #region Delete
            public int DeletePlanById(Plan p)
            { 
                return ExecuteNonQuery("DeletePlanById",createParameter("@P_Id",p.P_ID));
            }
            public int DeletePlanByRou_Id(Plan p)
            {
                return ExecuteNonQuery("DeletePlanByRou_Id", createParameter("@Rou_Id", p.Rou_ID));
            }
            public int DeletePlanByPP_Id(Plan p)
            {
                return ExecuteNonQuery("DeletePlanByPP_Id", createParameter("@PP_Id", p.PP_ID));
            }
            public int DeletePlanByBus_Number(Plan p)
            {
                return ExecuteNonQuery("DeletePlanByBus_Number", createParameter("@Bus_Number", p.BusNumber));
            }
            public int DeletePlanByTS_Id(Plan p)
            {
                return ExecuteNonQuery("DeletePlanByTS_Id", createParameter("@TS_Id", p.TS_ID));
            }
            public int DeletePlanByStartDate(Plan p)
            {
                return ExecuteNonQuery("DeletePlanByStartDate", createParameter("@StartDate", p.StartDate));
            }
        #endregion
    }
}