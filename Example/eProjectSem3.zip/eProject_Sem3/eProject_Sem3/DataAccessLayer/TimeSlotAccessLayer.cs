﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer.Library;
using Entity;
using System.Data;
namespace DataAccessLayer
{
    public class TimeSlotAccessLayer : ExecuteDataBase
    {

        public TimeSlotAccessLayer()
        {

        }
        private static List<TimeSlot> ConvertDataTableToList(DataTable dt)
        {
            List<TimeSlot> Lt = new List<TimeSlot>();
            foreach (DataRow item in dt.Rows)
            {

                Lt.Add(ConvertDataRowToTimeSlot(item));
            }
            return Lt;
        }

        private static TimeSlot ConvertDataRowToTimeSlot(DataRow item)
        {
            TimeSlot ts = new TimeSlot();
            ts.TS_ID = Convert.ToInt32(item["TS_ID"]);
            ts.StartTime = item["StartTime"].ToString();
            ts.EndTime = item["EndTime"].ToString();
            return ts;
        }

        public List<TimeSlot> SelectAllTimeSlot()
        {

            DataTable dt = ExecuteDataTable("SelectAllTimeSlot", null);
            return ConvertDataTableToList(dt);
        }

     
    }
}