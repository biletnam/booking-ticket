﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer.Library;
using Entity;
using System.Data;

namespace DataAccessLayer
{
    public class TicketViewAccessLayer : ExecuteDataBase
    {
        DataTable dt;
        public TicketViewAccessLayer()
        {

        }

        //Ham chuyen 1 ban ghi thanh 1 doi tuong
        private TicketViews ConvetDataRowToViewTicketInfo(DataRow item)
        {
            TicketViews TV = new TicketViews();
            TV.BUSTYPE = item["BusType"].ToString();
            TV.BUS_NUMBER = item["Bus_Number"].ToString();
            TV.CUS_ID = Convert.ToInt32(item["Cus_Id"]);
            TV.CUSTOMERNAME = item["CustomerName"].ToString();
            TV.PARKINGPLACE = item["ParkingPlace"].ToString();
            TV.STARTDATE = Convert.ToDateTime(item["StartDate"]);
            TV.STARTPLACE = item["StartPlace"].ToString();
            TV.ENDPLACE = item["EndPlace"].ToString();
            TV.STARTTIME = item["StartTime"].ToString();
            TV.ENDTIME = item["EndTime"].ToString();
            TV.T_ID = Convert.ToInt32(item["T_Id"]);
            TV.SEATNUMBER =Convert.ToInt32(item["SeatNumber"]);
            TV.PRICE = Convert.ToDouble(item["Price"]);
            TV.STATUSRETURN = Convert.ToBoolean(item["Return"]);
            TV.STATUSISSUE = Convert.ToBoolean(item["Status"]);
            return TV;
        }

        //ham tim kiem
        public List<TicketViews> FindBy(string column, string value)
        {
            IDataParameter[] idp = new IDataParameter[3];
            idp[0] = createParameter("@Table", "TicketViews");
            idp[1] = createParameter("@Column", column);
            idp[2] = createParameter("@Value", value);
            DataTable dt = ExecuteDataTable("Find", idp);
            return GetListFromDataTable(dt);
        }

        //Ham gan bang vao list doi tuong
        private List<TicketViews> GetListFromDataTable(DataTable dt)
        {
            List<TicketViews> LTV = new List<TicketViews>();

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    LTV.Add(ConvetDataRowToViewTicketInfo(item));
                }

            }
            return LTV;
        }

        #region Select
        //Select all TicketViews
        public List<TicketViews> SelectAllTicketViews()
        {
            dt = ExecuteDataTable("ProcViewTicket", null);
            return GetListFromDataTable(dt);
        }
        #endregion


    }
}