﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using  DataAccessLayer.Library;
using Entity;
using BusinessObjectLayer;

namespace DataAccessLayer
{
    public class DiminishAccessLayer:ExecuteDataBase
    {
         DataTable dt;
         public DiminishAccessLayer()
        {

        }
        private Diminish ConvertDataRowToDiminsih(DataRow dr)
        {
            Diminish dm = new Diminish();
            dm.DI_ID = Convert.ToInt32(dr["DI_Id"]);
            dm.DayNumberBefor1 = Convert.ToInt32(dr["DayNumberBefor"]);
            dm.DiminishPercent1 = Convert.ToInt32(dr["DiminishPercent"]);
            return dm;
        }
        private List<Diminish> GetListFromDataTable(DataTable dt)
        {
            List<Diminish> lbt = new List<Diminish>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dtr in dt.Rows)
                {
                    lbt.Add(ConvertDataRowToDiminsih(dtr));
                }
            }
            return lbt;
        }
        #region SelectDiminish

        public List<Diminish> SelectDiminishByID(Diminish dm)
        {
            DataTable dr = new DataTable();
            dr = ExecuteDataTable("SelectDiminishByID", createParameter("@DI_Id",dm.DI_ID));
            return GetListFromDataTable(dr);
        }

        public List<Diminish> SelectAllDiminish()
        {
            DataTable dr = new DataTable();
            dr = ExecuteDataTable("SelectAllDiminish", null);
            return GetListFromDataTable(dr);
        }

        public int CheckDiminishExistByID(Diminish dm)
        {
            int i = 0;
            dt = new DataTable();
            dt = ExecuteDataTable("SelectAllDiminish", null);
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }
      
        #endregion

        #region InsertDiminish
        public int InsertDiminish(Diminish dm)
        {
            IDataParameter[] idp = new IDataParameter[2];
            idp[0] = createParameter("@DayNumberBefor", dm.DayNumberBefor1);
            idp[1] = createParameter("@DiminishPercent", dm.DiminishPercent1);            
            return ExecuteNonQuery("InsertDiminish", idp);
        }
        #endregion

        #region UpdateDiminish
        public int UpdateDiminishID(Diminish dm)
        {
            IDataParameter[] idp = new IDataParameter[3];
            idp[0] = createParameter("@DI_Id", dm.DI_ID);
            idp[1] = createParameter("@DayNumberBefor", dm.DayNumberBefor1);
            idp[2] = createParameter("@DiminishPercent", dm.DiminishPercent1);
            return ExecuteNonQuery("UpdateDiminishID", idp);
        }
       
        #endregion

        #region DeleteDiminish

        public int DeleteDiminishID(Diminish dm)
        {
            return ExecuteNonQuery("DeleteDiminishID", createParameter("@DI_Id", dm.DI_ID));
        }
        
        #endregion
     
    }
}