﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using DataAccessLayer.Library;
using Entity;

namespace  DataAccessLayer
{
   public class CityAccessLayer:ExecuteDataBase
    {
       
        #region SelectCity

       private City ConvertDataRowToCity(DataRow dr)
       {
           City ct = new City();
           ct.Ci_ID = Convert.ToInt32(dr["Ci_Id"]);
           ct.Name = dr["Name"].ToString();
           return ct;
       }

       private List<City> GetListFromDataTable(DataTable dt)
       {
           List<City> lc = new List<City>();
           if (dt.Rows.Count > 0)
           {
               foreach (DataRow dtr in dt.Rows)
               {
                   lc.Add(ConvertDataRowToCity(dtr));
               }
           }
           return lc;
       }

       public List<City> SelectAllCity()
        { 
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectAllCity", null);
            return GetListFromDataTable(dt);
        }
       public List<City> SelectCityByID(City ct)
        {
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectCityByID",createParameter("@Ci_Id",ct.Ci_ID));
            return GetListFromDataTable(dt);
        }
       public List<City> SelectCityByName(City ct)
        {
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectCityByName",createParameter("@Name",ct.Name));
            return GetListFromDataTable(dt);
        }

       public int CheckCityExistByName(City ct)
        {
            int i =0;
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectCityByName", createParameter("@Name", ct.Name));
            if (dt.Rows.Count == 0)
            {                
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }
       public int CheckCityExistByID(City ct)
        {
            int i = 0;
            DataTable dt = new DataTable();
            dt = ExecuteDataTable("SelectCityByID", createParameter("@Ci_Id", ct.Ci_ID));
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }

        #endregion

        #region InsertCity
       public int InsertCity(City ct)
        {
            return ExecuteNonQuery("InsertCity", createParameter("@Name", ct.Name));
        }
        #endregion

        #region UpdateCity
       public int UpdateCityByID(City ct)
        {
            IDbDataParameter[] idb = new IDbDataParameter[2];
            idb[0] = createParameter("@Ci_Id", ct.Ci_ID);
            idb[1] = createParameter("@Name", ct.Name);
            return ExecuteNonQuery("UpdateCityByID",idb);
        }
       public int UpdateCityByName(City ct)
        {
            return ExecuteNonQuery("UpdateCityByName", createParameter("@Name", ct.Name));
        }
        #endregion
        #region DeleteCity
       public int DeleteCityByID(City ct)
        {
            return ExecuteNonQuery("DeleteCityByID", createParameter("@Ci_Id", ct.Ci_ID));
        }
       public int DeleteCityByName(City ct)
        {
            return ExecuteNonQuery("DeleteCityByName", createParameter("@Name",ct.Name));
        }
        #endregion
    }
}
