﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using DataAccessLayer.Library;
using Entity;

namespace DataAccessLayer
{
    public class BranchAccessLayer : ExecuteDataBase
    {
        DataTable dt;
        public BranchAccessLayer()
        { }

        private Branch ConvertDataRowToBranch(DataRow item)
        {
            Branch b = new Branch();
            b.B_ID = Convert.ToInt32(item["B_id"]);
            b.NAME = item["Name"].ToString();
            b.PHONENUMBER = item["PhoneNumber"].ToString();
            b.ADDRESS = item["Address"].ToString();
            b.STATUS = Convert.ToBoolean(item["Status"]);
            return b;
        }

        private List<Branch> getListFromDataTable(DataTable dt)
        {
            List<Branch> lb = new List<Branch>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    lb.Add(ConvertDataRowToBranch(item));
                }
            }
            return lb;
        }


        #region Select
        public List<Branch> getAllBranch()
        {
            DataTable dt = ExecuteDataTable("SelectAllBranch", null);
            return getListFromDataTable(dt);
        }

        public List<Branch> getBranchbyID(int ID)
        {
            DataTable dt = ExecuteDataTable("SelectBranch", createParameter("@B_id", ID));
            return getListFromDataTable(dt);
        }

        public List<Branch> getBranchbyName(string Name)
        {
            DataTable dt = ExecuteDataTable("SelectBranchbyName", createParameter("@Name", Name));
            return getListFromDataTable(dt);
        }
        #endregion

        #region Check
        public int CheckBranchExistByID(int id)
        {
            int i = 0;
            dt = new DataTable();
            dt = ExecuteDataTable("SelectBranch", createParameter("@B_id", id));
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }
        public int CheckBusTypeExistByName(String name)
        {
            int i = 0;
            dt = new DataTable();
            dt = ExecuteDataTable("SelectBranchbyName", createParameter("@Name", name));
            if (dt.Rows.Count == 0)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            return i;
        }
        #endregion

        #region Insert
        public int InsertBranch(string Name, string PhoneNumber, string Address, Boolean Status)
        {
            IDataParameter[] id = new IDataParameter[4];
            id[0] = createParameter("@Name", Name);
            id[1] = createParameter("@PhoneNumber", PhoneNumber);
            id[2] = createParameter("@Address", Address);
            id[3] = createParameter("@Status", Status);
            return ExecuteNonQuery("InsertBranch", id);
        }
        #endregion

        #region Delete
        public int DeleteBranch(int ID)
        {
            return ExecuteNonQuery("DeleteBranch", createParameter("@B_id", ID));
        }
        #endregion

        #region Update
        public int UpdateBranch(int ID, string Name, string PhoneNumber, string Address, Boolean Status)
        {
            IDataParameter[] id = new IDataParameter[5];
            id[0] = createParameter("@B_id", ID);
            id[1] = createParameter("@Name", Name);
            id[2] = createParameter("@PhoneNumber", PhoneNumber);
            id[3] = createParameter("@Address", Address);
            id[4] = createParameter("@Status", Status);
            return ExecuteNonQuery("UpdateBranch", id);
        }
        #endregion
    }
}