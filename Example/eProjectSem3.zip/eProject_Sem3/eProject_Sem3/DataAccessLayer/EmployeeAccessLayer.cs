﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using DataAccessLayer.Library;
using Entity;

namespace DataAccessLayer
{
    public class EmployeeAccessLayer : ExecuteDataBase
    {
        public EmployeeAccessLayer()
        { }

        private Employee ConvertDataRowToEmployee(DataRow item)
        {
            Employee em = new Employee();
            em.E_ID = item["E_Id"].ToString();
            em.FirstName = item["Firstname"].ToString();
            em.LastName = item["Lastname"].ToString();
            em.USERNAME = item["UserName"].ToString();
            em.PASS = item["Pass"].ToString();
            em.QualiFiCation = item["Qualification"].ToString();
            em.BirthDay = Convert.ToDateTime(item["Birthday"]);
            em.LocaTion = Convert.ToInt32(item["Location"]);
            em.LV_ID = Convert.ToInt32(item["LV_Id"]);
            em.StaTus = Convert.ToBoolean(item["Status"]);
            return em;
        }

        private List<Employee> getListFromDataTable(DataTable dt)
        {
            List<Employee> le = new List<Employee>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {
                    le.Add(ConvertDataRowToEmployee(item));
                }
            }
            return le;
        }

        #region Select
        public List<Employee> getAllEmployee()
        {
            DataTable dt = ExecuteDataTable("SelectAllEmployee", null);
            return getListFromDataTable(dt);
        }

        public List<Employee> getEmployeebyID(string ID)
        {
            DataTable dt = ExecuteDataTable("SelectEmployee", createParameter("@E_Id", ID));
            return getListFromDataTable(dt);
        }

        public List<Employee> getEmployeebyNameFirst(string Name)
        {
            DataTable dt = ExecuteDataTable("SelectEmployeebyFirstName", createParameter("@Firstname", Name));
            return getListFromDataTable(dt);
        }
        #endregion

        #region Insert
        public int InsertEmployee(string E_Id, string Firstname, string Lastname, string UserName, string Pass, string Qualification, DateTime Birthday, int Location, int LV_Id, Boolean Status)
        {
            IDataParameter[] id = new IDataParameter[10];
            id[0] = createParameter("@E_Id", E_Id);
            id[1] = createParameter("@Firstname", Firstname);
            id[2] = createParameter("@Lastname", Lastname);
            id[3] = createParameter("@UserName", UserName);
            id[4] = createParameter("@Pass", Pass);
            id[5] = createParameter("@Qualification", Qualification);
            id[6] = createParameter("@Birthday", Birthday);
            id[7] = createParameter("@Location", Location);
            id[8] = createParameter("@LV_Id", LV_Id);
            id[9] = createParameter("@Status", Status);
            return ExecuteNonQuery("InsertEmployee", id);
        }
        #endregion

        #region Delete
        public int DeleteEmployee(string ID)
        {
            return ExecuteNonQuery("DeleteEmployee", createParameter("@E_Id", ID));
        }
        #endregion

        #region Update
        public int UpdateEmployee(string E_Id, string Firstname, string Lastname, string UserName, string Pass, string Qualification, DateTime Birthday, int Location, int LV_Id, Boolean Status)
        {
            IDataParameter[] id = new IDataParameter[10];
            id[0] = createParameter("@E_Id", E_Id);
            id[1] = createParameter("@Firstname", Firstname);
            id[2] = createParameter("@Lastname", Lastname);
            id[3] = createParameter("@UserName", UserName);
            id[4] = createParameter("@Pass", Pass);
            id[5] = createParameter("@Qualification", Qualification);
            id[6] = createParameter("@Birthday", Birthday);
            id[7] = createParameter("@Location", Location);
            id[8] = createParameter("@LV_Id", LV_Id);
            id[9] = createParameter("@Status", Status);
            return ExecuteNonQuery("UpdateEmployee", id);
        }
        #endregion
    }
}