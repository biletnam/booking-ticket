﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using DataAccessLayer;
using Entity;
namespace BusinessObjectLayer
{
   public class Bol_City
    {
       CityAccessLayer btac;
        public Bol_City()
        {
            btac = new CityAccessLayer();
        }
      

        #region Select

        public List<City> SelectAllCity()
        {
            return btac.SelectAllCity();
        }
        public List<City> SelectCityByID(City ct)
        {
            return btac.SelectCityByID(ct);
        }
        public List<City> SelectCityByName(City ct)
        {
            return btac.SelectCityByName(ct);
        }
        public int CheckCityExistByName(City ct)
        {            
            return btac.CheckCityExistByName(ct);
        }
        public int CheckCityExistByID(City ct)
        {            
            return btac.CheckCityExistByID(ct);
        }       
        #endregion
        #region Insert
        public int InsertCity(City ct)
        {
            return btac.InsertCity(ct);
        }
        #endregion
        #region UpdateCity
        public int UpdateCityByID(City ct)
        {
            return btac.UpdateCityByID(ct);
        }
        public int UpdateCityByName(City ct)
        {
            return btac.UpdateCityByName(ct);
        }
        #endregion
        #region Delete
        public int DeleteCityByID(City ct)
        {
            return btac.DeleteCityByID(ct);
        }
        public int DeleteCityByName(City ct)
        {
            return btac.DeleteCityByName(ct);
        }
        #endregion
    }
}
