﻿using System;
using System.Collections.Generic;
using System.Web;
using Entity;
using System.Data;
using DataAccessLayer;

namespace BusinessObjectLayer
{
    public class Bol_Route
    {
        RouteAccessLayer RAL;
        public Bol_Route()
        {
            RAL = new RouteAccessLayer();
        }
        #region Select        
        public List<Route> SelectAllRoute()
        {

            return RAL.SelectAllRoute();
        }

       
        #endregion
       
    }

}