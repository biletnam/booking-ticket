﻿using System;
using System.Collections.Generic;
using System.Web;
using Entity;
using DataAccessLayer;
namespace BusinessObjectLayer
{
    public class Bol_Bus
    {
        BusAccessLayer Bal;
        public Bol_Bus()
        {
            Bal = new BusAccessLayer();
        }
        public List<Bus> SelectAllBus()
        {
            return Bal.SelectAllBus();
        }
          #region Insert

        public int InsertBus(Bus b)
        {
            return Bal.InsertBus(b);
        }
          #endregion
        #region Update
        public int UpdateBusByBusNumber(Bus b)
        {            
            return  Bal.UpdateBusByBusNumber(b);
        }
        #endregion
       
    }
}