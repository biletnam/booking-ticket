﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer;
using System.Data;
using Entity;

namespace BusinessObjectLayer
{
    public class Bol_Employee
    {
        EmployeeAccessLayer ea;
        #region Select
        public Bol_Employee()
        {
            ea = new EmployeeAccessLayer();
        }

        public List<Employee> getAllEmployee()
        {
            return ea.getAllEmployee();
        }

        public List<Employee> getEmployeebyID(Employee e)
        {
            return ea.getEmployeebyID(e.E_ID);
        }

        public List<Employee> getemployeebyName(Employee e)
        {
            return ea.getEmployeebyNameFirst(e.FirstName);
        }
        #endregion

        #region Insert
        public int InsertEmployee(Employee e)
        {
            return ea.InsertEmployee(e.E_ID, e.FirstName, e.LastName, e.USERNAME, e.PASS, e.QualiFiCation, e.BirthDay, e.LocaTion, e.LV_ID, e.StaTus);
        }
        #endregion

        #region Delete
        public int DeleteEmployee(Employee e)
        {
            return ea.DeleteEmployee(e.E_ID);
        }
        #endregion

        #region Update
        public int UpdateEmployee(Employee e)
        {
            return ea.UpdateEmployee(e.E_ID, e.FirstName, e.LastName, e.USERNAME, e.PASS, e.QualiFiCation, e.BirthDay, e.LocaTion, e.LV_ID, e.StaTus);
        }
        #endregion
    }
}