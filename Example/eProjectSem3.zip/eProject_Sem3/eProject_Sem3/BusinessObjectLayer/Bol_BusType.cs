﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer;
using System.Data.SqlClient;
using System.Data;
using Entity;

namespace BusinessObjectLayer
{
    public class Bol_BusType
    {
        BusTypeAccessData btac;
        public Bol_BusType()
        {
            btac = new BusTypeAccessData();
        }
      
        #region Select

        public List<BusType> SelectAllBusType()
        {
            return btac.SelectAllBusType();
        }
        public List<BusType> SelectBusTypeByID(BusType bt)
        {
            return btac.SelectBusTypeByID(bt);
        }
        public List<BusType> SelectBusTypeByName(BusType bt)
        {
            return btac.SelectBusTypeByName(bt);
        }
        public int CheckBusTypeExistByID(BusType bt)
        {            
            return btac.CheckBusTypeExistByID(bt);
                        
        }
        public int CheckBusTypeExistByName(BusType bt)
        {
            return btac.CheckBusTypeExistByName(bt);
        }
        #endregion
       
        #region Insert
        public int InsertBusType(BusType bt)
        {
            return btac.InsertBusType(bt);
        }
        #endregion

        #region UpdateBusType
        public int UpdateBusTypeByID(BusType bt)
        {
            return btac.UpdateBusTypeByID(bt);
        }
        public int UpdateBusTypeByName(BusType bt)
        {
            return btac.UpdateBusTypeByName(bt);
        }
        #endregion

        #region DeleteBusType
        public int DeleteBusTypeByID(BusType bt)
        {
            return btac.DeleteBusTypeByID(bt);
        }
        public int DeleteBusTypeByName(BusType bt)
        {
            return btac.DeleteBusTypeByName(bt);
        }
        #endregion

    }
}
