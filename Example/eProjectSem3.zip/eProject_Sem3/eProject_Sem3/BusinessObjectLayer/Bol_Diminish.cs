﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer;
using System.Data.SqlClient;
using System.Data;
using Entity;

namespace BusinessObjectLayer
{
    public class Bol_Diminish
    {
        DiminishAccessLayer dmal;
        public Bol_Diminish()
        {
            dmal = new DiminishAccessLayer();
        }

        public List<Diminish> SelectAllDiminish()
        {
            return dmal.SelectAllDiminish();
        }
        public List<Diminish> SelectDiminishByID(Diminish dm)
        {
            return dmal.SelectDiminishByID(dm);
        }
        public int InsertDiminish(Diminish dm)
        {
            return dmal.InsertDiminish(dm);
        }
        public int UpdateDiminish(Diminish dm)
        {
            return dmal.UpdateDiminishID(dm);
        }
        public int DeleteDiminishByID(Diminish dm)
        {
            return dmal.DeleteDiminishID(dm);
        }
    }
}