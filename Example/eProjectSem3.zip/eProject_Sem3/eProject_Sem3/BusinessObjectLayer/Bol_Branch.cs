﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer;
using System.Data;
using Entity;

namespace BusinessObjectLayer
{
    public class Bol_Branch
    {
        BranchAccessLayer ba;
        public Bol_Branch()
        {
            ba = new BranchAccessLayer();
        }
        #region Select
        public List<Branch> getAll()
        {
            return ba.getAllBranch();
        }

        public List<Branch> getAllbyID(Branch b)
        {
            return ba.getBranchbyID(b.B_ID);
        }

        public List<Branch> getAllbyName(Branch b)
        {
            return ba.getBranchbyName(b.NAME);
        }
        #endregion

        public int CheckBranchExistByID(int id)
        {
            return ba.CheckBranchExistByID(id);

        }
        public int CheckBranchExistByName(string name)
        {
            return ba.CheckBusTypeExistByName(name);
        }

        public int InsertBranch(Branch b)
        {
            return ba.InsertBranch(b.NAME, b.PHONENUMBER, b.ADDRESS, b.STATUS);
        }

        public int DeleteBranch(Branch b)
        {
            return ba.DeleteBranch(b.B_ID);
        }

        public int UpdateBranch(Branch b)
        {
            return ba.UpdateBranch(b.B_ID, b.NAME, b.PHONENUMBER, b.ADDRESS, b.STATUS);
        }
    }
}