﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer;
using System.Data;
using Entity;

namespace BusinessObjectLayer
{
    public class Bol_Customer
    {
        CustomerAccessLayer cus_al;
        public Bol_Customer()
        {
            cus_al = new CustomerAccessLayer();
        }

        //Select All
        public List<Customers> SelectAllCustomer()
        {
            return cus_al.SelectAllCustomer();
        }

        //Search by LastName
        public List<Customers> SearchCustomer(String column,String value)
        {
            return cus_al.FindBy(column, value);
        }

        //Delete customer
        public List<Customers> DeleteCustomer(Customers cus)
        {
            return cus_al.deleteCus(cus);
        }

        //Update Customer
        public int UpdateCustomer(Customers cus)
        {
            return cus_al.UpdateCustomer(cus);
        }
        #region Booking
        public int BookingTicket(Customers Cus, int Sa_ID, int P_ID)
        {
            return cus_al.BookingTicket(Cus, Sa_ID, P_ID);
        }
        #endregion
    }
}