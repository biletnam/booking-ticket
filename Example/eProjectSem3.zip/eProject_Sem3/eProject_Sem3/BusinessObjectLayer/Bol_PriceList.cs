﻿using System;
using System.Collections.Generic;
using System.Web;
using Entity;
using DataAccessLayer;
namespace BusinessObjectLayer
{
   
    public class Bol_PriceList
    {
        RouteAccessLayer rAL;
        public Bol_PriceList()
        {
            rAL = new RouteAccessLayer();
        }
        
    }
}