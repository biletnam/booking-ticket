﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer;
using Entity;
using System.Data;

namespace BusinessObjectLayer
{
    public class Bol_Parking_Place
    {
        Parking_PlaceAccessLayer btac;
        public Bol_Parking_Place()
        {
            btac = new Parking_PlaceAccessLayer();
        }

        #region Select

        public List<Parking_Place> SelectAllParking_Place()
        {
            return btac.GetAllParking_Place();
        }
        public List<Parking_Place> SelectParking_PlaceByID(Parking_Place pp)
        {
            return btac.GetParking_PlaceByID(pp);
        }
        public List<Parking_Place> SelectParking_PlaceByName(Parking_Place pp)
        {
            return btac.GetParking_PlaceByName(pp);
        }
        public int CheckParking_PlaceExistByID(Parking_Place pp)
        {
            return btac.CheckParking_PlaceExistByID(pp);
        }
        public int CheckParking_PlaceExistByName(Parking_Place pp)
        {
            return btac.CheckParking_PlaceExistByName(pp);
        }
        
        #endregion
        #region Insert
        public int InsertParking_Place(Parking_Place pp)
        {
            return btac.InsertParking_Place(pp);
        }
        #endregion
        #region Update
        public int UpdateParking_PlaceByID(Parking_Place pp)
        {
            return btac.UpdateParking_PlaceByID(pp);
        }
        public int UpdateParking_PlaceByName(Parking_Place pp)
        {
            return btac.UpdateParking_PlaceByName(pp);
        }
        #endregion
        #region Delete
        public int DeleteParking_PlaceByID(Parking_Place pp)
        {
            return btac.DeleteParking_PlaceByID(pp);
        }
        public int DeleteParking_PlaceByName(Parking_Place pp)
        {
            return btac.DeleteParking_PlaceByName(pp);
        }
        #endregion


    }
}
