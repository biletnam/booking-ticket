﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using DataAccessLayer;
using Entity;

namespace BusinessObjectLayer
{
    public class Bol_TicketReturn
    {
         TicketReturnAccessLayer tkr;
        public Bol_TicketReturn()
        {
            tkr = new TicketReturnAccessLayer();
        }

        public List<TicketReturn> SelectAllTicketReturn()
        {
            return tkr.SelectAllTicketReturn();
        }
        public List<TicketReturn> SelectTicketReturnByID(TicketReturn tkrt)
        {
            return tkr.SelectTicketReturnByID(tkrt);
        }
        public int InsertTicketReturn(TicketReturn tkrt)
        {
            return tkr.InsertTicketReturn(tkrt);
        }
        public int DeleteTicketReturnByID(TicketReturn tkrt)
        {
            return tkr.DeleteTicketReturnByID(tkrt);
        }

    }
}