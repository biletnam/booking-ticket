﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer;
using System.Data;
using Entity;

namespace BusinessObjectLayer
{
    public class Bol_LevelAuthority
    {
        LevelAuthorityDataAccessLayer la;
        public Bol_LevelAuthority()
        {
            la = new LevelAuthorityDataAccessLayer();
        }

        public List<LevelAuthority> getAllLevel()
        {
            return la.getAllLevel();
        }

        public List<LevelAuthority> getLevelbyID(LevelAuthority lau)
        {
            return la.getLevelbyID(lau.LV_ID);
        }

        public List<LevelAuthority> getLevelbyName(LevelAuthority lau)
        {
            return la.getLevelbyName(lau.NAME);
        }

        public int InsertLevel(LevelAuthority lau)
        {
            return la.InsertLevel(lau.NAME, lau.STATUS);
        }

        public int DeleteLevel(LevelAuthority lau)
        {
            return la.DeleteLevel(lau.LV_ID);
        }

        public int UpdateLevel(LevelAuthority lau)
        {
            return la.UpdateLevel(lau.LV_ID, lau.NAME, lau.STATUS);
        }
    }
}