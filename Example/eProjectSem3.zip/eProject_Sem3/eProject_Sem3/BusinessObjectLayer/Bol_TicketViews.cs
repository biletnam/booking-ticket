﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer;
using Entity;

namespace BusinessObjectLayer
{
    public class Bol_TicketViews
    {
        TicketViewAccessLayer tval;
        public Bol_TicketViews()
        {
            tval = new TicketViewAccessLayer();
        }

        public List<TicketViews> GetAllTicketView()
        {
            return tval.SelectAllTicketViews();
        }

    }
}