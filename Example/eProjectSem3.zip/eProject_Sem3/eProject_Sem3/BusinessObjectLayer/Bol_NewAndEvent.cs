﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using DataAccessLayer;
using Entity;

namespace BusinessObjectLayer
{


    public class Bol_NewAndEvent
    {
        NewAndEventsAccessLayer nea;

        public Bol_NewAndEvent()
        {
            nea = new NewAndEventsAccessLayer();
        }
        public List<NewAndEvent> SelectNewAndEvent()
        {
            return nea.SelectNewAndEvent();
        }
        public List<NewAndEvent> SelectbyID(NewAndEvent id)
        {
            return nea.selectByID(id.NE_Id);
        }

        public int InsertNewAndEvent(NewAndEvent nae)
        {
            return nea.InsertNewAndEvent(nae.Title, nae.Content, nae.Author, nae.Date, nae.Status);

        }
        public List<NewAndEvent> SelectTitleNewAndEvent(NewAndEvent Title)
        {
            return nea.SelectTitleNewandEvent(Title.Title);
        }
        public int UpdateNewAndEvent(NewAndEvent nae)
        {
            return nea.UpdateNewAndEvent(nae.NE_Id, nae.Title, nae.Content, nae.Author, nae.Date, nae.Status);
        }
        public int DeleteNewAndEventID(NewAndEvent id)
        {
            return nea.DeleteNewAndEventID(id.NE_Id);
        }
        public List<NewAndEvent> SelectNewAndEventContent(NewAndEvent Content)
        {
            return nea.SelectNewandEventContent(Content.Content);
        }
        public List<NewAndEvent> SelectNewAndEventAuthor(NewAndEvent author)
        {
            return nea.SelectNewandEventAuthor(author.Author);
        }
        public List<NewAndEvent> SelectNewAndEventDate(NewAndEvent date)
        {
            return nea.SelectNewandEventDate(date.Date);
        }
        public List<NewAndEvent> SelectNewAndEventStatus(NewAndEvent status)
        {
            return nea.SelectNewandEventStatus(status.Status);
        }



    }
}

