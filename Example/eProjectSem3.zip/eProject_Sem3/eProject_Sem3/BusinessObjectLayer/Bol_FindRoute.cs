﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer;
using Entity;
namespace BusinessObjectLayer
{
    
    public class Bol_FindRoute
    {
        FindRouteInfomationAccessLayer fri;
        public Bol_FindRoute()
        {
            fri = new FindRouteInfomationAccessLayer();
        }
        public List<SearchRouteInfomation> FindRouteResult(FindPacket pk)
        {
           return fri.FindRouteResult( pk);
        }
       


    }
}