﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using DataAccessLayer;
using Entity;

namespace BusinessObjectLayer
{
    
    public class Bol_Sales
    {
        SalesAccessLayer sad;
        public Bol_Sales()
        {
            sad = new SalesAccessLayer();
        }

        public List<Sales> SelectSalesAll()
        {
            return sad.GetAllSales();
        }
        public List<Sales> SelectSalesID(Sales id)
        {
            return sad.GetSalesByID(id);
        }
        public List<Sales> SelectSalesName(Sales name)
        {
            return sad.GetSalesByName(name);
        }
        public int InsertSales(Sales sa)
        {
            return sad.InsertSales(sa);
        }
        public int UpdateSalesID(Sales sa)
        {
            return sad.UpdateSalesByID(sa);
        }
        public int UpdateSalesName(Sales sa)
        {
            return sad.UpdateSalesByName(sa);
        }
        public int DeleteSalesID(Sales sa)
        {
            return sad.DeleteSalesByID(sa);
        }
        public int DeleteSalesName(Sales sa)
        {
            return sad.DeleteSalesByName(sa);
        }
    }
}