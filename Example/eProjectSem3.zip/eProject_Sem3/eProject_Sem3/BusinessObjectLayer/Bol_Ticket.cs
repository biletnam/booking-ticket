﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer;
using Entity;

namespace BusinessObjectLayer
{
    public class Bol_Ticket
    {
        TicketAccessLayer tk_al;
        public Bol_Ticket()
        {
            tk_al = new TicketAccessLayer();
        }

        //Update ticket.status by ID
        public int UpdateTicket(Ticket tk)
        {
            return tk_al.UpdateTicket(tk);
        }
    }
}