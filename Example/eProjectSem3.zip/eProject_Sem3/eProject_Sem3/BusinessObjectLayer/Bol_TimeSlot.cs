﻿using System;
using System.Collections.Generic;
using System.Web;
using DataAccessLayer;
using Entity;
namespace BusinessObjectLayer
{
    public class Bol_TimeSlot
    {
        TimeSlotAccessLayer Tsal;
        public Bol_TimeSlot()
        {
            Tsal = new TimeSlotAccessLayer();
        }
        public List<TimeSlot> SelectAllTimeSlot()
        {
            return Tsal.SelectAllTimeSlot();
        }
    }
}