﻿using System;
using System.Collections.Generic;
using System.Web;
using Entity;
using DataAccessLayer;
namespace BusinessObjectLayer
{
    public class Bol_Plan
    {
        PlanAccessLayer pal;
        public Bol_Plan()
        {
            pal = new PlanAccessLayer();
        }
        #region Select
        #region Select ALL
        public List<Plan> SelectAllPlan()
        {

            return pal.SelectAllPlan();
        }

        #endregion
        #region Select By ID
        public List<Plan> SelectPlanById(Plan pl)
        {
            return SelectPlanById(pl);
        }

        #endregion
        #endregion
        #region Insert
        public int InsertPlan(Plan p)
        {
            return pal.InsertPlan(p);
        }
        #endregion

        #region Update
        public int UpdatePlanById(Plan p)
        {
            return pal.UpdatePlanById(p);
        }
        #endregion

        #region Delete
        public int DeletePlanById(Plan p)
        {
            return pal.DeletePlanById(p);
        }
        public int DeletePlanByRou_Id(Plan p)
        {
            return pal.DeletePlanByRou_Id(p);
        }
        public int DeletePlanByPP_Id(Plan p)
        {
            return pal.DeletePlanByPP_Id(p);
        }
        public int DeletePlanByBus_Number(Plan p)
        {
            return pal.DeletePlanByBus_Number(p);
        }
        public int DeletePlanByTS_Id(Plan p)
        {
            return pal.DeletePlanByTS_Id(p);
        }
        public int DeletePlanByStartDate(Plan p)
        {
            return pal.DeletePlanByStartDate(p);
        }
        #endregion
    }
}