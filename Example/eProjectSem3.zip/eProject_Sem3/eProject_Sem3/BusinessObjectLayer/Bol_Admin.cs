﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using DataAccessLayer;
using Entity;

namespace BusinessObjectLayer
{
   
    public class Bol_Admin
    {
        AdminAccessLayer ad;
        public Bol_Admin()
        {
            ad = new AdminAccessLayer();
        }
        public List<Admin> SelectAllAdmin()
        {
            return ad.SelectAllAdmin();
        }
        public int InsertAdmin(Admin adm)
        {
            return ad.InsertAdmin(adm.Username, adm.pass, adm.Fullname, adm.address, adm.phoneNumber);

        }
        public int UpdateAdmin(Admin adm)
        {
            return ad.UpdateAdmin(adm.Username, adm.pass, adm.Fullname, adm.address, adm.phoneNumber, adm.A_id);
        }
        public int DeleteAdmin(Admin adm)
        {
            return ad.DeleteAdmin(adm.A_id);
        }
        public List<Admin> SelectAdminID(Admin id)
        {
            return ad.SelectAdminID(id.A_id);
        }
        public List<Admin> SelectAdminName(Admin UserName)
        {
            return ad.SelectAdminName(UserName.Username);
        }
        public List<Admin> SelectAdminFullName(Admin FullName)
        {
            return ad.SelectAdminFullName(FullName.Fullname);
        }
        public List<Admin> SelectAdminAddress(Admin Address)
        {
            return ad.SelectAdminAddress(Address.address);
        }
        public List<Admin> SelectAdminPhone(Admin PhoneNumber)
        {
            return ad.SelectAdminPhoneNumber(PhoneNumber.phoneNumber);
        }
        public List<Admin> SelectAdminPass(Admin passWord)
        {
            return ad.SelectAdminPass(passWord);
        }
        public int CheckAdmin(Admin adm)
        {
            return ad.CheckAdmin(adm);
        }
        

    }
}