﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
namespace OBTRS.UserControlList
{
    public partial class FormRegister : System.Web.UI.UserControl
    {
        public String Name="";
        protected void Page_Load(object sender, EventArgs e)
        {
            Title.Text = Name;
        }

        public int sales_ID;

        public Customers GetCustomerInfor()
        {
            Customers cs = new Customers();
            cs.FIRSTNAME = txtFName.Text;
            cs.LASTNAME = txtLName.Text;
            cs.PHONENUMBER = txtPhone.Text;
            cs.EMAIL = txtEmail.Text;
            cs.ADDRESS = txtAddress.Text;
            cs.FIRSTNAME = txtFName.Text;
            cs.REGISTERDATE = DateTime.Now;
            return cs;
        }
    }
}