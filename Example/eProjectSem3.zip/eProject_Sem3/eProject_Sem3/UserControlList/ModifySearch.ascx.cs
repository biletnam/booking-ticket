﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObjectLayer;
using Entity;
namespace OBTRS.UserControlList
{
    public partial class ModifySearch : System.Web.UI.UserControl
    {
        Bol_BusType bBT;
        FindPacket src;
        protected void Page_Load(object sender, EventArgs e)
        {

            bBT = new Bol_BusType();
           
            src=(FindPacket) Session["Fpk"];
            if (!IsPostBack)
            {
                SetDropdowList();
            }
        }
        private void SetDropdowList()
        {
            if (src != null)
            {
                DrBustype.DataSource = bBT.SelectAllBusType();
                DrBustype.DataValueField = "BT_ID";
                DrBustype.DataTextField = "Name";
                DrBustype.DataBind();
                DrBustype.SelectedValue = src.BusType.ToString();
                DrSenior.SelectedValue = src.Senior.ToString();
                DrAdult.SelectedValue = src.Adult.ToString();
                DrChild.SelectedValue = src.Child.ToString();
                DrInfan.SelectedValue = src.Infan.ToString();
                date1.Value = src.StartDate.ToShortDateString();
            }
        }


        protected void Find_Click(object sender, EventArgs e)
        {

            try
            {
               
                String date = date1.Value;
                if (date != "")
                {
                    try
                    {
                        DateTime dt = Convert.ToDateTime(date);
                        if (DrSenior.SelectedIndex == 0 && DrAdult.SelectedIndex == 0)
                        {
                            Message.Text = "Traveler must least 1 adult or 1 senior";
                        }
                        else
                        {

                            src.BusType = Convert.ToInt32(DrBustype.SelectedValue);
                            src.StartDate = dt;
                            src.Senior = Convert.ToInt32(DrSenior.SelectedValue);
                            src.Adult = Convert.ToInt32(DrAdult.SelectedValue);
                            src.Child = Convert.ToInt32(DrChild.SelectedValue);
                            src.Infan = Convert.ToInt32(DrInfan.SelectedValue);
                            Session["Fpk"] = src;
                            Response.Redirect("~/BookingTicket.aspx");
                            Message.Text = "";
                        }
                    }
                    catch (Exception)
                    {

                        Message.Text = "Input Date Not Format!";
                    }


                }
                else
                {
                    Message.Text = "Please Choose Leave Date";
                }

            }
            catch (Exception)
            {

            }


        }
    }
}