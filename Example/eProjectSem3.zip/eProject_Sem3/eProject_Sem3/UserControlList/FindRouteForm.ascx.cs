﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObjectLayer;
using Entity;
using System.Web.UI.HtmlControls;
namespace OBTRS.UserControlList
{
    public partial class FindRouteForm : System.Web.UI.UserControl
    {

        Bol_BusType bBT;
        Bol_City bCT;
        protected void Page_Load(object sender, EventArgs e)
        {

            bBT = new Bol_BusType();
            bCT = new Bol_City();

            if (!IsPostBack)
            {
                SetDropdowList();
            }
        }
        private void SetDropdowList()
        {
            DrBustype.DataSource = bBT.SelectAllBusType();
            DrBustype.DataValueField = "BT_ID";
            DrBustype.DataTextField = "Name";
            DrBustype.DataBind();
            DrFrom.DataSource = bCT.SelectAllCity();
            DrFrom.DataValueField = "Ci_ID";
            DrFrom.DataTextField = "Name";
            DrFrom.DataBind();
            DrTo.DataSource = bCT.SelectAllCity();
            DrTo.DataValueField = "Ci_ID";
            DrTo.DataTextField = "Name";
            DrTo.DataBind();

        }
      

        protected void Find_Click(object sender, EventArgs e)
        {

            try
            {
                FindPacket src = new FindPacket();
                String date = date1.Value;
                if (date != "")
                {
                    try
                    {
                        DateTime dt = Convert.ToDateTime(date);
                        int from = Convert.ToInt32(DrFrom.SelectedValue);
                        int to = Convert.ToInt32(DrTo.SelectedValue);
                        if (from != to)
                        {
                            if (DrSenior.SelectedIndex == 0 && DrAdult.SelectedIndex == 0)
                            {
                                Message.Text = "Traveler must least 1 adult or 1 senior";
                            }
                            else
                            {

                                src.BusType = Convert.ToInt32(DrBustype.SelectedValue);
                                src.StartPlace = from;
                                src.EndPlace = to;
                                src.StartDate = dt;
                                src.Senior = Convert.ToInt32(DrSenior.SelectedValue);
                                src.Adult = Convert.ToInt32(DrAdult.SelectedValue);
                                src.Child = Convert.ToInt32(DrChild.SelectedValue);
                                src.Infan = Convert.ToInt32(DrInfan.SelectedValue);
                                Session["Fpk"] = src;
                                Response.Redirect("~/BookingTicket.aspx");
                                Message.Text = "";
                            }
                        }
                        else
                        {
                            Message.Text = "FromPlace must Diffent ToPlace  ";
                        }
                    

                   
                    }
                    catch (Exception)
                    {

                        Message.Text = "Input Date Not Format!";
                    }
                    
                   
                }
                else
                {
                    Message.Text = "Please Choose Leave Date";
                }

            }
            catch (Exception)
            {

            }


        }
    }
}