﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessObjectLayer;
using Entity;
namespace eProject_Sem3.UserControlList
{
    public partial class PlanManagerment : System.Web.UI.UserControl
    {
        Bol_Plan bPl;
        Bol_Route bRo;
        Bol_Parking_Place bPp;
        Bol_TimeSlot bTs;
        protected void Page_Load(object sender, EventArgs e)
        {
            bPl = new Bol_Plan();
            bRo = new Bol_Route();
            bPp = new Bol_Parking_Place();
            bTs = new Bol_TimeSlot();
            if (!Page.IsPostBack)
                BindData();
        }
        public String GetRName(int ID)
        {
            return bRo.SelectAllRoute().Find(delegate(Route rt)
            {
                return rt.Rou_ID == ID;
            }).Name;
        }
        public String GetPPName(int ID)
        {
            return bPp.SelectAllParking_Place().Find(delegate(Parking_Place rt)
            {
                return rt.PP_ID == ID;
            }).Name;
        }
        private void BindData()
        {
            GridView1.DataSource = bPl.SelectAllPlan();
            GridView1.DataBind();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            BindData();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            BindData();
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            BindData();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        
    }
}